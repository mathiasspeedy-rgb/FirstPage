class GameFlowManager:

	def __init__(self, engine):

		self.engine = engine
		self.state = "fight"

	# ======================
	# STATE CONTROL
	# ======================
	def start_fight(self):

		self.state = "fight"

	def enter_choice(self):

		self.state = "choice"

	# ======================
	# SPAWN SYSTEM
	# ======================
	def spawn_mob(self):

		enemy = self.engine.spawn_mob()
		self.start_fight()

		return {
			"type": "enemy_spawn",
			"enemy": {
				"type": "mob",
				"name": enemy.name,
				"tier": self.engine.progress.current_tier
			}
		}

	def spawn_boss(self):

		enemy = self.engine.spawn_boss()
		self.start_fight()

		return {
			"type": "enemy_spawn",
			"enemy": {
				"type": "boss",
				"name": enemy.name,
				"tier": self.engine.progress.current_tier
			}
		}

	def can_spawn_boss(self):
		return self.engine.progress.boss_available

	# ======================
	# RESULT HANDLING
	# ======================
	def handle_fight_result(self, result):

		# ======================
		# CASE: COMBAT CONTINUES NORMALLY
		# ======================
		if result["result"] == "continue":
			return {
				"result": "continue",
				"state": self.state,
				"log": result
			}

		# ======================
		# CASE: PLAYER DIED
		# ======================
		if result["result"] == "player_dead":
			return {
				"result": "player_dead",
				"state": self.state,
				"log": result
			}

		# ======================
		# CASE: INVALID ACTION (no turn was played)
		# ======================
		if result["result"] == "invalid_action":
			return {
				"result": "invalid_action",
				"state": self.state,
				"log": result
			}

		# ======================
		# CASE: ENEMY DIED
		# ======================
		if result["result"] == "enemy_dead":

			reward = self.engine.progress.resolve_reward(result)
			xp_log = self.engine.apply_rewards(reward)

			response = {
				"result": "enemy_dead",
				"state": self.state,
				"log": result,

				"enemy_type": result["enemy_type"],

				"xp": xp_log["xp_gained"],
				"lvl_up": xp_log["lvl_up"],

				"tier_advanced": False,
				"tier_intro": None,
				"last_tier_over": False
			}

			# ======================
			# BOSS -> NEXT TIER
			# ======================
			if result["enemy_type"] == "boss":

				if reward.get("was_last_tier"):
					response["tier_advanced"] = False
					response["last_tier_over"] = True

				else:
					new_tier = self.engine.progress.current_tier

					response["tier_advanced"] = True
					response["new_tier"] = new_tier
					response["tier_intro"] = self.engine.tier_factory.get_intro(new_tier)

			self.enter_choice()

			return response

		# ======================
		# FALLBACK (should not happen, but never return None)
		# ======================
		return {
			"result": result.get("result", "unknown"),
			"state": self.state,
			"log": result
		}

	# ======================
	# REST
	# ======================
	def rest(self):

		return self.engine.player.make_rest()
