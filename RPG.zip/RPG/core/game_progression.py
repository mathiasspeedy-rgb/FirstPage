class GameProgression:
	def __init__(self, tier_factory):
		self.tier_factory = tier_factory

		self.current_tier = 1
		self.current_kill = 0
		self.total_mob_kill = 0
		self.boss_available = False

	def is_last_tier(self):
		return self.tier_factory.get_tier_count() == self.current_tier

	def get_kill_to_boss(self):
		return self.tier_factory.get(self.current_tier)["kill_to_boss"]

	# ======================
	# MOB KILLED EVENT
	# ======================
	def on_mob_killed(self):
		self.current_kill += 1
		self.total_mob_kill += 1

		xp = 50 * self.current_tier

		# check si boss déja available
		was_available = self.boss_available

		# condition unlock
		if not self.boss_available and self.current_kill >= self.get_kill_to_boss():
			self.boss_available = True

		# évènement
		boss_unlocked = (not was_available and self.boss_available)

		return {
			"xp": xp,
			"boss_unlocked": boss_unlocked,
		}

	# ======================
	# BOSS KILLED EVENT
	# ======================
	def on_boss_killed(self):
		xp = 150 * self.current_tier

		was_last_tier = self.is_last_tier()

		if not was_last_tier:
			self.current_tier += 1

		self.current_kill = 0
		self.boss_available = False

		return {
			"xp": xp,
			"boss_available": self.boss_available,
			"boss_unlocked": False,
			"new_tier": self.current_tier,
			"was_last_tier": was_last_tier
		}

	def resolve_reward(self, result):
		if result["enemy_type"] == "mob":
			return self.on_mob_killed()
		elif result["enemy_type"] == "boss":
			return self.on_boss_killed()
