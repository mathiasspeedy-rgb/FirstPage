from core.engine import Engine
from core.game_flow_manager import GameFlowManager
from core.game_loop import GameLoop
from ui import UI


def main():

	engine = Engine()
	flow = GameFlowManager(engine)
	ui = UI()

	loop = GameLoop(engine, ui, flow)
	loop.run()


if __name__ == "__main__":
	main()
