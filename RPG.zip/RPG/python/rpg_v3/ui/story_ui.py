class StoryUI:

	def __init__(self, ui):
		self.ui = ui

	def write(self, text):
		self.ui.blank()
		self.ui.write(text, center=False)
		self.ui.blank()

	def title(self, text):
		self.ui.title(text)
