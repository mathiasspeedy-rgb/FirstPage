class IntroUI:

	def __init__(self, ui):
		self.ui = ui


	def intro(self):

		self.ui.line()

		self.ui.write("L'ABYSS")

		self.ui.line()

		self.ui.blank()

		self.ui.write(
			"Tu t'apprêtes à descendre dans les profondeurs."
		)

		self.ui.write(
			"Chaque choix peut être fatal."
		)

		self.ui.blank()

		self.ui.separator()

	def name_phase(self):

		self.ui.blank()

		self.ui.write(
			"Une voix surgit des profondeurs..."
		)

		self.ui.write(
			"QUI ÊTES-VOUS ?!"
		)

		self.ui.write(
			"Pensez-vous être digne ?"
		)

		self.ui.blank()

		name = self.ask_name()

		self.ui.blank()

		self.ui.write(
			"Vous pouvez entrer..."
		)

		self.ui.blank()

		return name

	def ask_name(self):

		while True:

			name = input("Nom: > ")

			if name == "":
				name = "Hero"

			if self.confirm_choice(name):
				return name

	def confirm_choice(self, label):

		self.ui.blank()

		self.ui.write(f"{label} ?")
		self.ui.write("Es-tu sûr ?")

		self.ui.blank()

		self.ui.write("1. Oui")
		self.ui.write("2. Non")

		self.ui.blank()

		while True:
			try:
				choice = int(input("> "))

				if choice == 1:
					return True

				if choice == 2:
					return False

			except ValueError:
				pass

			self.ui.write("Entre 1 ou 2")

	def archetype_phase(self, archetypes):

		self.ui.blank()

		self.ui.write(
			"Une force ancienne s'éveille en vous..."
		)

		self.ui.write(
			"Elle vous observe... elle vous juge..."
		)

		self.ui.write(
			"Votre essence commence à se révéler."
		)

		self.ui.blank()

		self.ui.write(
			"Quel destin allez-vous incarner ?"
		)

		self.ui.blank()

		while True:

			self.list_archetypes(archetypes)

			index = self.ask_archetype(archetypes)

			archetype = archetypes[index]

			self.ui.blank()

			if self.confirm_choice(archetype.name):
				return archetype

			self.ui.write("Très bien... choisissez à nouveau.")
			self.ui.blank()

	def list_archetypes(self, archetypes):

		self.ui.blank()

		for i, arc in enumerate(archetypes):

			self.ui.write(
				f"{i+1}. {arc.name}",
				center=True
			)

		self.ui.blank()

	def ask_archetype(self, archetypes):

		while True:

			try:
				choice = int(input("> ")) - 1

				if 0 <= choice < len(archetypes):
					return choice

			except ValueError:
				pass

			self.ui.write("Choix invalide", center=True)

	def welcome(self, name, archetype):

		self.ui.line()

		self.ui.write(
			"Vous entrez dans le donjon..."
		)

		self.ui.blank()

		self.ui.write(
			f"Bienvenue ({archetype}), Pardon je voulais dire ... {name}"
		)

		self.ui.blank()

		self.ui.line()



	def run_intro(self, archetypes):

		self.intro()

		name = self.name_phase()

		archetype = self.archetype_phase(archetypes)

		self.welcome(name, archetype.name)

		return name, archetype