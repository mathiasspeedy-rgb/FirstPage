class UI:

	def __init__(self, length=170):

		self.length = length

		from .intro_ui import IntroUI
		from .fight_ui import CombatUI
		from .story_ui import StoryUI
		from .choice_ui import ChoiceUI

		self.intro = IntroUI(self)
		self.combat = CombatUI(self)
		self.story = StoryUI(self)
		self.choice = ChoiceUI(self)

	# ======================
	# WRITE FLEXIBLE
	# ======================

	def write(self, text="", center=True):

		if center:
			print(text.center(self.length))
		else:
			print(text)

	def blank(self):
		print()

	def line(self):
		print("=" * self.length)

	def separator(self):
		print("-" * self.length)

	def title(self, text):

		self.line()
		self.write(text, center=True)
		self.line()
		self.blank()
