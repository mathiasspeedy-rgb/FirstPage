class ChoiceUI:

	def __init__(self, ui):
		self.ui = ui

	def show_choice(self, can_boss=False):

		while True:

			self.ui.title("CHOIX")

			self.ui.write("1. Affronter un nouvel ennemi", center=False)
			self.ui.write("2. Se reposer", center=False)

			if can_boss:
				self.ui.write("3. Affronter le boss du palier", center=False)

			self.ui.blank()

			choice = input("> ")

			if choice == "1":
				return "1"

			if choice == "2":
				return "2"

			if choice == "3" and can_boss:
				return "3"

			self.ui.write("Choix invalide", center=False)
			self.ui.blank()
