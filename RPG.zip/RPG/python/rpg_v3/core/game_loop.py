class GameLoop:

	def __init__(self, engine, ui, flow):

		self.engine = engine
		self.ui = ui
		self.flow = flow

		self.state = "INTRO"
		self.running = True

	# ======================
	# MAIN LOOP
	# ======================
	def run(self):

		self.intro()

		self.state = "FIGHT"

		while self.running:

			if self.state == "FIGHT":
				self.fight_step()

			elif self.state == "CHOICE":
				self.choice_step()

	# ======================
	# INTRO FLOW
	# ======================
	def intro(self):

		archetypes = self.engine.archetype_factory.list()

		name, archetype = self.ui.intro.run_intro(archetypes)

		player = self._create_player(name, archetype)

		# engine.start() assigns the player AND spawns the first enemy
		# (Engine cannot do either before the player exists).
		self.engine.start(player)

		# ======================
		# TIER 1 INTRO (DONJON ENTRY)
		# ======================
		tier_intro = self.engine.tier_factory.get_intro(1)
		self.ui.story.write(tier_intro)

		self.ui.combat.announce_enemy(
			self.engine.current_enemy.name,
			is_boss=(self.engine.current_enemy.entity_type == "boss"),
			is_first=True
		)

	def _create_player(self, name, archetype):
		return self.engine.archetype_factory.build_player(name, archetype)

	# ======================
	# FIGHT STEP
	# ======================
	def fight_step(self):

		self.ui.combat.show_status(
			self.engine.player,
			self.engine.current_enemy,
			self.engine.turn_count
		)

		action = self.ui.combat.get_action_name(self.engine.player, self.engine.current_enemy)

		combat_result = self.engine.fight(action)

		game_result = self.flow.handle_fight_result(combat_result)

		self.ui.combat.render_fight_log(combat_result)

		if game_result["result"] == "invalid_action":
			# nothing happened, just loop back and ask again
			return

		if game_result["result"] == "enemy_dead":

			self.ui.combat.render_reward_log(game_result)

			self.engine.reset_combat_state()

			self.state = "CHOICE"

		elif game_result["result"] == "player_dead":

			self.game_over()

	# ======================
	# CHOICE STEP
	# ======================
	def choice_step(self):

		choice = self.ui.choice.show_choice(
			can_boss=self.flow.can_spawn_boss()
		)

		if choice == "1":

			spawn_result = self.flow.spawn_mob()
			self.ui.combat.announce_enemy(
				spawn_result["enemy"]["name"],
				is_boss=False
			)
			self.state = "FIGHT"

		elif choice == "2":

			self.flow.rest()
			self.state = "CHOICE"

		elif choice == "3":

			spawn_result = self.flow.spawn_boss()
			self.ui.combat.announce_enemy(
				spawn_result["enemy"]["name"],
				is_boss=True
			)
			self.state = "FIGHT"

	# ======================
	# GAME OVER
	# ======================
	def game_over(self):

		self.ui.story.write("Vous êtes tombé dans l'Abyss...")
		self.ui.story.write("Fin de votre voyage.")

		self.running = False
