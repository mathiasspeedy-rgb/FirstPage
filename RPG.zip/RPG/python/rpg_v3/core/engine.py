import random

from factories.mob_factory import MobFactory
from factories.boss_factory import BossFactory
from factories.tier_factory import TierFactory
from factories.archetype_factory import ArchetypeFactory
from core.game_progression import GameProgression


class Engine:

	def __init__(self):

		# ======================
		# FACTORIES (single source of truth)
		# ======================
		self.mob_factory = MobFactory()
		self.boss_factory = BossFactory()
		self.tier_factory = TierFactory()
		self.archetype_factory = ArchetypeFactory()

		self.progress = GameProgression(self.tier_factory)

		# ======================
		# DEFERRED STATE (set in start())
		# ======================
		# No Player exists yet at this point (name/archetype are only known
		# once the intro UI sequence has run), so Engine must be constructable
		# without one. Nothing below is usable until start() is called.
		self.player = None
		self.current_enemy = None
		self.turn_count = 1

	# ======================
	# DEFERRED START (called once the player is known)
	# ======================
	def start(self, player):

		self.player = player
		self.current_enemy = self._spawn_mob()
		self.turn_count = 1

	# ======================
	# SPAWN HELPERS
	# ======================
	def _spawn_mob(self):
		return self.mob_factory.get_random_mob(self.progress.current_tier)

	def _spawn_boss(self):
		return self.boss_factory.get_boss(self.progress.current_tier)

	def spawn_mob(self):
		self.current_enemy = self._spawn_mob()
		self.turn_count = 1
		return self.current_enemy

	def spawn_boss(self):
		self.current_enemy = self._spawn_boss()
		self.turn_count = 1
		return self.current_enemy

	# ======================
	# CORE LOOP
	# ======================
	def fight(self, action):

		player = self.player
		enemy = self.current_enemy

		log = {
			"player": {},
			"enemy": {},
			"enemy_type": enemy.entity_type,
			"enemy_name": enemy.name
		}

		# ======================
		# PLAYER TURN (SKILLS)
		# ======================
		if action in player.skills:

			skill = player.skills[action]

			if action in ("heal",):
				log["player"] = skill.use(player, player)
			else:
				log["player"] = skill.use(player, enemy)

		else:
			log["player"] = {
				"type": "fail",
				"reason": "invalid_action"
			}
			log["result"] = "invalid_action"
			return log

		# ======================
		# ENEMY DEAD CHECK
		# ======================
		if not enemy.is_alive:
			log["result"] = "enemy_dead"
			return log

		# ======================
		# ENEMY TURN (AI)
		# ======================
		if enemy.entity_type == "mob":
			log["enemy"] = self.mob_ai(enemy, player)

		elif enemy.entity_type == "boss":
			log["enemy"] = self.boss_ai(enemy, player)

		else:
			log["enemy"] = {
				"type": "error",
				"reason": "invalid_entity_type"
			}

		if not player.is_alive:
			log["result"] = "player_dead"
			return log

		# ======================
		# TICK (STATUS SYSTEM)
		# ======================
		log["events"] = self.next_turn()
		log["result"] = "continue"
		log["turn"] = self.turn_count

		if not player.is_alive:
			log["result"] = "player_dead"

		return log

	# ======================
	# MOB AI
	# ======================
	def mob_ai(self, enemy, player):

		available_actions = ["attack"]

		for skill_name in ("defense", "heal", "blind"):
			if skill_name in enemy.skills and enemy.skills[skill_name].is_ready():
				available_actions.append(skill_name)

		if "ult" in enemy.skills and enemy.skills["ult"].is_ready():
			available_actions.append("ult")

		choice = random.choice(available_actions)

		# heal/defense target the caster itself, attack/blind/ult target the player
		if choice in ("heal", "defense"):
			return enemy.skills[choice].use(enemy, enemy)

		return enemy.skills[choice].use(enemy, player)

	# ======================
	# BOSS AI
	# ======================
	def boss_ai(self, enemy, player):

		hp_ratio = enemy.pv / enemy.pvmax

		# 1. ULT PRIORITY
		if "ult" in enemy.skills and enemy.skills["ult"].is_ready():
			return enemy.skills["ult"].use(enemy, player)

		# 2. HEAL LOW HP
		if "heal" in enemy.skills and hp_ratio < 0.5 and enemy.skills["heal"].is_ready():
			return enemy.skills["heal"].use(enemy, enemy)

		# 3. DEFENSE MID HP
		if "defense" in enemy.skills and hp_ratio < 0.7 and enemy.skills["defense"].is_ready():
			if random.random() < 0.6:
				return enemy.skills["defense"].use(enemy, enemy)

		# 4. BLIND IF NOT AFFECTED
		if "blind" in enemy.skills and not player.has_status("blind") and enemy.skills["blind"].is_ready():
			if random.random() < 0.5:
				return enemy.skills["blind"].use(enemy, player)

		# 5. DEFAULT ATTACK
		return enemy.skills["attack"].use(enemy, player)

	# ======================
	# TICK SYSTEM
	# ======================
	def next_turn(self):

		events = []

		# PLAYER STATUS TICK
		events.extend(self.player.tick())

		# ENEMY STATUS TICK
		events.extend(self.current_enemy.tick())

		self.turn_count += 1

		return events

	# ======================
	# XP / REWARDS
	# ======================
	def apply_rewards(self, reward):

		xp_gained = reward.get("xp", 0)

		old_lvl = self.player.lvl
		new_lvl_up = self.player.add_xp(xp_gained)

		return {
			"xp_gained": xp_gained,
			"xp_current": self.player.xp,
			"level_before": old_lvl,
			"level_after": self.player.lvl,
			"lvl_up": new_lvl_up
		}

	def reset_combat_state(self):

		# reset du combat courant
		self.turn_count = 1
