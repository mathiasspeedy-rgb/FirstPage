from factories.archetype import Archetype
from factories.skill_factory import SkillFactory


class ArchetypeFactory:
	def __init__(self):
		self.archetypes = self._build_archetypes()

	def _build_archetypes(self):
		return {

			# ======================
			# HERCULE
			# ======================
			"hercule": Archetype(
				id=1,
				name="Hercule",
				pvmax=110,
				base_dmg=9,
				crit_rate=0.10,

				# skill_defs: passed to SkillFactory.build_all() when a Player
				# is created from this archetype (one fresh set of Skill
				# instances per Player).
				skill={
					"attack": {
						"name": "Etranglement",
						"cooldown": 0,
						"bricks": {
							"dmg": {"mult": 1.0}
						}
					},
					"ult": {
						"name": "Force Herculéenne",
						"cooldown": 3,
						"skip_accuracy_check": True,
						"bricks": {
							"dmg": {"mult": 2.0, "use_crit": False, "ignore_defense": True}
						}
					}
				},
			),

			# ======================
			# ULYSSE
			# ======================
			"ulysse": Archetype(
				id=2,
				name="Ulysse",
				pvmax=85,
				base_dmg=12,
				crit_rate=0.35,

				skill={
					"attack": {
						"name": "Feinte",
						"cooldown": 0,
						"bricks": {
							"dmg": {"mult": 1.0}
						}
					},
					"ult": {
						"name": "Cheval de Troie",
						"cooldown": 3,
						"skip_accuracy_check": True,
						"bricks": {
							"dmg": {"mult": 5.0, "use_crit": False, "ignore_defense": True}
						}
					}
				},
			),

			# ======================
			# LEONIDAS
			# ======================
			"léonidas": Archetype(
				id=3,
				name="Léonidas",
				pvmax=150,
				base_dmg=7,
				crit_rate=0.05,

				skill={
					"attack": {
						"name": "Frappe de phalange",
						"cooldown": 0,
						"bricks": {
							"dmg": {"mult": 1.0}
						}
					},
					"defense": {
						"name": "Garde de Sparte",
						"cooldown": 3,
						"bricks": {
							"apply_status": {
								"status": "defense",
								"def_rate": 0.4,
								"turns": 2
							}
						}
					},
					"ult": {
						"name": "Dernier rempart",
						"cooldown": 2,
						"skip_accuracy_check": True,
						"bricks": {
							"dmg": {"mult": 6.0, "use_crit": False, "ignore_defense": True}
						}
					}
				},
			),

			# ======================
			# PYTHIE
			# ======================
			"pythie": Archetype(
				id=4,
				name="Pythie",
				pvmax=100,
				base_dmg=8,
				crit_rate=0.10,

				skill={
					"attack": {
						"name": "Frappe Rituelle",
						"cooldown": 0,
						"bricks": {
							"dmg": {"mult": 1.0}
						}
					},
					"heal": {
						"name": "Bénédiction",
						"cooldown": 2,
						"bricks": {
							"heal": {"amount": 40}
						}
					},
					"ult": {
						"name": "Chatiment Divin",
						"cooldown": 2,
						"skip_accuracy_check": True,
						"bricks": {
							"dmg": {"mult": 5.0, "use_crit": False, "ignore_defense": True}
						}
					}
				},
			),

			# ======================
			# RAMSES
			# ======================
			"ramses": Archetype(
				id=5,
				name="Ramsès",
				pvmax=95,
				base_dmg=9,
				crit_rate=0.12,

				skill={
					"attack": {
						"name": "Spectre Royal",
						"cooldown": 0,
						"bricks": {
							"dmg": {"mult": 1.0}
						}
					},
					"blind": {
						"name": "Tempête de Sable",
						"cooldown": 4,
						"bricks": {
							"apply_status": {
								"status": "blind",
								"blind_rate": 0.7,
								"turns": 2
							}
						}
					},
					"ult": {
						"name": "Colère du Pharaon",
						"cooldown": 2,
						"skip_accuracy_check": True,
						"bricks": {
							"dmg": {"mult": 5.0, "use_crit": False, "ignore_defense": True}
						}
					}
				},
			),

			# ======================
			# RAGNAR
			# ======================
			"ragnar": Archetype(
				id=6,
				name="Ragnar",
				pvmax=90,
				base_dmg=10,
				crit_rate=0.10,

				skill={
					"attack": {
						"name": "Hache du Nord",
						"cooldown": 0,
						"bricks": {
							"dmg": {"mult": 1.0}
						}
					},
					"boost": {
						"name": "Eveil du Berserk",
						"cooldown": 6,
						"bricks": {
							"affect_stat": {
								"stat": "base_dmg",
								"type": "positive",
								"level": 1
							}
						}
					},
					"ult": {
						"name": "Ragnarock",
						"cooldown": 8,
						"skip_accuracy_check": True,
						"bricks": {
							"dmg": {"mult": 3.2, "use_crit": False, "ignore_defense": True}
						}
					}
				},
			),

			# ======================
			# ICARE (burn)
			# ======================
			"icare": Archetype(
				id=7,
				name="Icare",
				pvmax=85,
				base_dmg=8,
				crit_rate=0.15,

				skill={
					"attack": {
						"name": "Chute Ardente",
						"cooldown": 0,
						"bricks": {
							"dmg": {"mult": 1.0}
						}
					},
					"burn": {
						"name": "Soleil Instable",
						"cooldown": 3,
						"bricks": {
							"apply_status": {
								"status": "burn",
								"damage": 5
							}
						}
					},
					"ult": {
						"name": "Déchu",
						"cooldown": 4,
						"skip_accuracy_check": True,
						"bricks": {
							"dmg": {"mult": 4.0, "use_crit": False, "ignore_defense": True}
						}
					}
				},
			),

			# ======================
			# MÉDÉE (poison)
			# ======================
			"medee": Archetype(
				id=8,
				name="Médée",
				pvmax=95,
				base_dmg=7,
				crit_rate=0.10,

				skill={
					"attack": {
						"name": "Lame d'Herbès",
						"cooldown": 0,
						"bricks": {
							"dmg": {"mult": 1.0}
						}
					},
					"poison": {
						"name": "Toxine",
						"cooldown": 3,
						"bricks": {
							"apply_status": {
								"status": "poison",
								"damage": 3,
								"growth": 2
							}
						}
					},
					"ult": {
						"name": "Vengeance",
						"cooldown": 4,
						"skip_accuracy_check": True,
						"bricks": {
							"dmg": {"mult": 4.5, "use_crit": False, "ignore_defense": True}
						}
					}
				},
			),

			# ======================
			# DRACULA (lifesteal: dmg + heal)
			# ======================
			"dracula": Archetype(
				id=9,
				name="Dracula",
				pvmax=130,
				base_dmg=9,
				crit_rate=0.12,

				skill={
					"attack": {
						"name": "Morsure",
						"cooldown": 0,
						"bricks": {
							"dmg": {"mult": 1.0}
						}
					},
					"lifesteal": {
						"name": "Drain de Sang",
						"cooldown": 2,
						"bricks": {
							"dmg": {"order": 1, "mult": 1.0},
							"heal": {"order": 2, "percent_of_dmg": 0.4}
						}
					},
					"ult": {
						"name": "Sang Eternel",
						"cooldown": 4,
						"skip_accuracy_check": True,
						"bricks": {
							"dmg": {"mult": 3.0, "use_crit": False, "ignore_defense": True}
						}
					}
				},
			),
		}

	def get(self, key):
		return self.archetypes.get(key)

	def list(self):
		return list(self.archetypes.values())

	def create_player(self, name, archetype_id):
		"""Builds a Player by archetype key/id (looks it up first)."""
		archetype = self.get(archetype_id)
		return self.build_player(name, archetype)

	def build_player(self, name, archetype):
		"""
		Single point of construction for a Player, given an already-resolved
		Archetype object. Builds the Skill instances (one fresh set per
		Player, never shared) and hands the finished Player back.
		entities.Player itself never touches SkillFactory directly, which is
		what keeps entities/ independent from factories/ (no import cycle).
		"""
		from entities.player import Player

		skills = SkillFactory.build_all(archetype.skill)

		return Player(name, archetype, skills)
