class TierFactory:
	def __init__(self):
		self.tiers = {
			1: {
				"kill_to_boss": 8,
				"intro": "Vous descendez dans les premiers niveaux de l'Abyss..."
			},
			2: {
				"kill_to_boss": 8,
				"intro": "L'air devient plus lourd. Les ennemis se font plus rusés."
			},
			3: {
				"kill_to_boss": 12,
				"intro": "Les murs semblent se refermer sur vous. Restez vigilant."
			},
			4: {
				"kill_to_boss": 16,
				"intro": "Une présence ancienne rôde dans ces profondeurs."
			},
			5: {
				"kill_to_boss": 20,
				"intro": "Vous touchez le fond de l'Abyss. Ce qui vous attend ici n'a jamais été vaincu."
			},
		}

	def get(self, tier):
		return self.tiers[tier]

	def get_tier_count(self):
		return len(self.tiers)

	def get_intro(self, tier):
		return self.tiers[tier]["intro"]
