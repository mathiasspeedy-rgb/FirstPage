import random
from entities.fighter import Fighter
from factories.skill_factory import SkillFactory


class MobFactory:
	def __init__(self):
		self.mob_pool = self._build_mob_pool()

	def _build_mob_pool(self):
		return {

			# ======================
			# PALIER 1 - BASIQUE
			# ======================
			1: [
				{"name": "Limon instable", "pvmax": 28, "base_dmg": 2, "crit_rate": 0.03},
				{"name": "Gobelin pillard", "pvmax": 30, "base_dmg": 3, "crit_rate": 0.05},
				{"name": "Rat infecté", "pvmax": 26, "base_dmg": 2, "crit_rate": 0.04},
				{"name": "Chiroptère des ruines", "pvmax": 24, "base_dmg": 3, "crit_rate": 0.05},
				{"name": "Limon corrosif", "pvmax": 29, "base_dmg": 2, "crit_rate": 0.03},
				{"name": "Araignée des tunnels", "pvmax": 27, "base_dmg": 3, "crit_rate": 0.04},
			],

			# ======================
			# PALIER 2 - INTRO CAPACITÉS
			# ======================
			2: [
				{
					"name": "Squelette cuirassé",
					"pvmax": 45,
					"base_dmg": 4,
					"crit_rate": 0.06,
					"has_defense": True,
					"defense_rate": 0.6,
					"defense_duration": 2
				},
				{
					"name": "Loup alpha",
					"pvmax": 43,
					"base_dmg": 5,
					"crit_rate": 0.10
				},
				{
					"name": "Paladin maléfique",
					"pvmax": 48,
					"base_dmg": 5,
					"crit_rate": 0.09,
					"has_defense": True,
					"defense_rate": 0.55,
					"defense_duration": 2
				},
				{
					"name": "Tisseuse des ombres",
					"pvmax": 40,
					"base_dmg": 4,
					"crit_rate": 0.08,
					"has_blind": True,
					"blind_rate": 0.6,
					"blind_duration": 2
				},
				{
					"name": "Revenant armé",
					"pvmax": 46,
					"base_dmg": 5,
					"crit_rate": 0.09
				},
				{
					"name": "Traqueur des ruines",
					"pvmax": 44,
					"base_dmg": 5,
					"crit_rate": 0.11
				},
			],

			# ======================
			# PALIER 3 - INTERMÉDIAIRE
			# ======================
			3: [
				{
					"name": "Mort-vivant vorace",
					"pvmax": 62,
					"base_dmg": 5,
					"crit_rate": 0.10,
					"has_heal": True,
					"heal_rate": 0.12
				},
				{
					"name": "Briseur orc",
					"pvmax": 74,
					"base_dmg": 7,
					"crit_rate": 0.12
				},
				{
					"name": "Occultiste des brumes",
					"pvmax": 58,
					"base_dmg": 8,
					"crit_rate": 0.10,
					"has_blind": True,
					"blind_rate": 0.55,
					"blind_duration": 2
				},
				{
					"name": "Lame fantôme",
					"pvmax": 52,
					"base_dmg": 8,
					"crit_rate": 0.18
				},
				{
					"name": "Colosse effondré",
					"pvmax": 78,
					"base_dmg": 6,
					"crit_rate": 0.08,
					"has_defense": True,
					"defense_rate": 0.6,
					"defense_duration": 2
				},
				{
					"name": "Dévoreur des tombes",
					"pvmax": 70,
					"base_dmg": 6,
					"crit_rate": 0.10,
					"has_heal": True,
					"heal_rate": 0.08
				},
			],

			# ======================
			# PALIER 4 - ÉLITE
			# ======================
			4: [
				{
					"name": "Gardien corrompu",
					"pvmax": 92,
					"base_dmg": 8,
					"crit_rate": 0.10,
					"has_defense": True,
					"defense_rate": 0.6,
					"defense_duration": 3
				},
				{
					"name": "Imprégné démoniaque",
					"pvmax": 118,
					"base_dmg": 11,
					"crit_rate": 0.12
				},
				{
					"name": "Arcaniste instable",
					"pvmax": 82,
					"base_dmg": 10,
					"crit_rate": 0.15,
					"has_blind": True,
					"blind_rate": 0.6,
					"blind_duration": 2
				},
				{
					"name": "Chimère déformée",
					"pvmax": 108,
					"base_dmg": 9,
					"crit_rate": 0.10
				},
				{
					"name": "Prêtre des ombres",
					"pvmax": 125,
					"base_dmg": 8,
					"crit_rate": 0.08,
					"has_heal": True,
					"heal_rate": 0.15
				},
				{
					"name": "Exécuteur abyssal",
					"pvmax": 115,
					"base_dmg": 12,
					"crit_rate": 0.14
				},
			],
		}

	# ======================
	# DATA -> skill_defs CONVERSION
	# ======================
	def _build_skill_defs(self, data):
		"""
		Converts the flat has_X/X_rate/X_duration flags used in the mob pool
		into skill_defs ready for SkillFactory.build_all().

		Every mob gets a base "attack" skill. Optional abilities are added
		only when their has_X flag is present.
		"""

		skill_defs = {
			"attack": {
				"cooldown": 0,
				"bricks": {
					"dmg": {"mult": 1.0}
				}
			}
		}

		if data.get("has_defense"):
			skill_defs["defense"] = {
				"cooldown": 3,
				"bricks": {
					"apply_status": {
						"status": "defense",
						"def_rate": data.get("defense_rate", 0.5),
						"turns": data.get("defense_duration", 2)
					}
				}
			}

		if data.get("has_blind"):
			skill_defs["blind"] = {
				"cooldown": 3,
				"bricks": {
					"apply_status": {
						"status": "blind",
						"blind_rate": data.get("blind_rate", 0.6),
						"turns": data.get("blind_duration", 2)
					}
				}
			}

		if data.get("has_heal"):
			skill_defs["heal"] = {
				"cooldown": 3,
				"bricks": {
					"heal": {"percent_of_dmg": 0, "amount": int(data["pvmax"] * data.get("heal_rate", 0.1))}
				}
			}

		return skill_defs

	def get_random_mob(self, tier):

		if tier not in self.mob_pool:
			raise NotImplementedError(
				f"Aucun mob defini pour le palier {tier} (TODO: completer mob_pool)"
			)

		data = random.choice(self.mob_pool[tier])

		skill_defs = self._build_skill_defs(data)
		skills = SkillFactory.build_all(skill_defs)

		return Fighter(
			name=data["name"],
			entity_type="mob",
			pvmax=data["pvmax"],
			base_dmg=data["base_dmg"],
			base_crit=data.get("crit_rate", 0.05),
			skills=skills
		)
