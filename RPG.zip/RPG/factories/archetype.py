class Archetype:

	def __init__(
		self,
		id,
		name,

		# ======================
		# BASE STATS
		# ======================
		pvmax,
		base_dmg,
		crit_rate=0.1,
		base_accuracy=0.9,

		# ======================
		# SKILL LOADOUT (skill_defs, see SkillFactory.build_all)
		# ======================
		skill=None
	):

		# identity
		self.id = id
		self.name = name

		# stats base
		self.pvmax = pvmax
		self.base_dmg = base_dmg
		self.crit_rate = crit_rate
		self.base_accuracy = base_accuracy

		# skill_defs (IMPORTANT: dict of skill name -> definition, not Skill instances)
		self.skill = skill or {}

	def to_dict(self):

		return {
			"id": self.id,
			"name": self.name,

			"pvmax": self.pvmax,
			"base_dmg": self.base_dmg,
			"crit_rate": self.crit_rate,
			"base_accuracy": self.base_accuracy,

			"skills": self.skill
		}
