from entities.skill import Skill


class SkillFactory:
	"""
	Single entry point to build Skill instances.

	IMPORTANT: build() must be called once PER FIGHTER. Skill instances are
	never shared between two Fighters, since cooldown state lives on the
	Skill instance itself.
	"""

	@staticmethod
	def build(name, cooldown=0, bricks=None, skip_accuracy_check=False, success_rate=1.0):

		return Skill(
			name=name,
			cooldown=cooldown,
			bricks=bricks or {},
			skip_accuracy_check=skip_accuracy_check,
			success_rate=success_rate
		)

	@classmethod
	def build_all(cls, skill_defs):
		"""
		Build a fresh dict[str, Skill] from a definitions dict, e.g.

		skill_defs = {
		    "attack": {
		        "cooldown": 0,
		        "bricks": {"dmg": {"mult": 1.0}}
		    },
		    "ult": {
		        "cooldown": 4,
		        "skip_accuracy_check": True,
		        "bricks": {"dmg": {"mult": 2.5, "use_crit": False, "ignore_defense": True}}
		    }
		}

		Always returns brand new Skill instances (never shared), so this is
		safe to call once per Fighter (Player, mob, boss).
		"""

		skills = {}

		for skill_name, definition in skill_defs.items():

			skills[skill_name] = cls.build(
				name=definition.get("name", skill_name),
				cooldown=definition.get("cooldown", 0),
				bricks=definition.get("bricks", {}),
				skip_accuracy_check=definition.get("skip_accuracy_check", False),
				success_rate=definition.get("success_rate", 1.0)
			)

		return skills
