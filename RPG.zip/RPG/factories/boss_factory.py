from entities.fighter import Fighter
from factories.skill_factory import SkillFactory


class BossFactory:
	def __init__(self):
		self.boss_pool = {
			1: self._boss_1,
			2: self._boss_2,
			3: self._boss_3,
			4: self._boss_4,
			5: self._boss_5
		}

	def get_boss(self, tier):
		tier = min(tier, 5)
		return self.boss_pool[tier]()

	# ======================
	# SKILL_DEFS BUILDER
	# ======================
	def _build_skills(self, ult_mult, ult_cooldown,
					   defense_rate=None, defense_duration=2,
					   blind_rate=None, blind_duration=2,
					   heal_amount=None):

		skill_defs = {
			"attack": {
				"cooldown": 0,
				"bricks": {
					"dmg": {"mult": 1.0}
				}
			},
			"ult": {
				"cooldown": ult_cooldown,
				"skip_accuracy_check": True,
				"bricks": {
					"dmg": {"mult": ult_mult, "use_crit": False, "ignore_defense": True}
				}
			}
		}

		if defense_rate is not None:
			skill_defs["defense"] = {
				"cooldown": 3,
				"bricks": {
					"apply_status": {
						"status": "defense",
						"def_rate": defense_rate,
						"turns": defense_duration
					}
				}
			}

		if blind_rate is not None:
			skill_defs["blind"] = {
				"cooldown": 4,
				"bricks": {
					"apply_status": {
						"status": "blind",
						"blind_rate": blind_rate,
						"turns": blind_duration
					}
				}
			}

		if heal_amount is not None:
			skill_defs["heal"] = {
				"cooldown": 4,
				"bricks": {
					"heal": {"amount": heal_amount}
				}
			}

		return skill_defs

	# ======================
	# BOSS 1 - no ability + ult only
	# ======================
	def _boss_1(self):
		skills = SkillFactory.build_all(self._build_skills(
			ult_mult=2.2, ult_cooldown=4
		))

		return Fighter(
			name="Rook, le Briseur",
			entity_type="boss",
			pvmax=120,
			base_dmg=15,
			base_crit=0.10,
			skills=skills
		)

	# ======================
	# BOSS 2 - blind
	# ======================
	def _boss_2(self):
		skills = SkillFactory.build_all(self._build_skills(
			ult_mult=2.4, ult_cooldown=4,
			blind_rate=0.6, blind_duration=2
		))

		return Fighter(
			name="Noctis, le Voilé",
			entity_type="boss",
			pvmax=180,
			base_dmg=20,
			base_crit=0.12,
			skills=skills
		)

	# ======================
	# BOSS 3 - heal
	# ======================
	def _boss_3(self):
		skills = SkillFactory.build_all(self._build_skills(
			ult_mult=2.5, ult_cooldown=4,
			heal_amount=int(250 * 0.25)
		))

		return Fighter(
			name="Vorthan, le Moissonneur de Vie",
			entity_type="boss",
			pvmax=250,
			base_dmg=22,
			base_crit=0.14,
			skills=skills
		)

	# ======================
	# BOSS 4 - defense
	# ======================
	def _boss_4(self):
		skills = SkillFactory.build_all(self._build_skills(
			ult_mult=2.6, ult_cooldown=3,
			defense_rate=0.5, defense_duration=2
		))

		return Fighter(
			name="Kaelgor, le Bastion Fracturé",
			entity_type="boss",
			pvmax=320,
			base_dmg=25,
			base_crit=0.15,
			skills=skills
		)

	# ======================
	# BOSS 5 - all abilities
	# ======================
	def _boss_5(self):
		skills = SkillFactory.build_all(self._build_skills(
			ult_mult=3.0, ult_cooldown=3,
			blind_rate=0.5, blind_duration=2,
			heal_amount=int(450 * 0.20),
			defense_rate=0.5, defense_duration=2
		))

		return Fighter(
			name="Apex, Reine de la Nuit",
			entity_type="boss",
			pvmax=450,
			base_dmg=30,
			base_crit=0.18,
			skills=skills
		)
