import random


# ======================
# AFFECT_STAT LEVEL TABLE
# ======================
# level -> multiplier applied (positive) or its inverse-ish counterpart (negative)
AFFECT_STAT_LEVELS = {
	1: 1.5,
	2: 2.0,
	3: 2.5,
	4: 3.0,
	5: 4.0,
}

# Default order applied when a brick config doesn't specify "order".
DEFAULT_BRICK_ORDER = {
	"dmg": 1,
	"recoil": 2,
	"heal": 3,
	"affect_stat": 4,
	"apply_status": 5,
	"remove_status": 6,
}

# Default target ("self" or "target") for each brick type when not overridden.
DEFAULT_BRICK_TARGET = {
	"dmg": "target",
	"recoil": "self",
	"heal": "self",
	"affect_stat": "self",
	"apply_status": "target",
	"remove_status": "target",
}

# Statuses that default to targeting self instead of the generic apply_status default.
STATUS_SELF_DEFAULT = {"defense", "guard"}


class Skill:

	def __init__(self, name, cooldown=0, bricks=None, skip_accuracy_check=False, success_rate=1.0):

		self.name = name
		self.cooldown = cooldown
		self.current_cooldown = 0

		# dict[str, dict] -> at most one brick of each type, e.g.
		# {"dmg": {...}, "apply_status": {...}}
		self.bricks = bricks or {}

		self.skip_accuracy_check = skip_accuracy_check
		self.success_rate = success_rate

	# ======================
	# COOLDOWN SYSTEM (per-instance, never shared between Fighters)
	# ======================

	def is_ready(self):
		return self.current_cooldown <= 0

	def trigger_cooldown(self):
		if self.cooldown > 0:
			self.current_cooldown = self.cooldown

	def tick(self):
		if self.current_cooldown > 0:
			self.current_cooldown -= 1

	# ======================
	# VALIDATION (used by UI before allowing the action)
	# ======================

	def can_use(self, caster, target=None):

		if not self.is_ready():
			return False, f"{self.name} est en recharge ({self.current_cooldown})"

		return self.check_specific(caster, target)

	def check_specific(self, caster, target):
		return True, ""

	# ======================
	# MAIN USE
	# ======================

	def use(self, user, target):

		# ======================
		# 1. COOLDOWN CHECK
		# ======================
		if not self.is_ready():
			return {
				"type": "fail",
				"reason": "cooldown",
				"actor": user.name,
				"skill": self.name
			}

		# ======================
		# 2. ACCURACY CHECK
		# ======================
		if not self.skip_accuracy_check:
			if not user.calculate_accuracy():
				self.trigger_cooldown()
				return {
					"type": "miss",
					"attacker": user.name,
					"target": target.name if target else None,
					"skill": self.name
				}

		# ======================
		# 3. SKILL SUCCESS ROLL (independent from accuracy)
		# ======================
		if random.random() >= self.success_rate:
			self.trigger_cooldown()
			return {
				"type": "fail",
				"reason": "skill_failed",
				"actor": user.name,
				"skill": self.name
			}

		# ======================
		# 4. EXECUTE BRICKS (sorted by order)
		# ======================
		ordered_bricks = sorted(
			self.bricks.items(),
			key=lambda item: item[1].get("order", DEFAULT_BRICK_ORDER.get(item[0], 99))
		)

		events = []
		last_damage_dealt = 0

		for brick_type, config in ordered_bricks:

			# Per-brick odds roll
			odds = config.get("odds", 1.0)
			if random.random() >= odds:
				continue

			handler = getattr(self, f"_brick_{brick_type}", None)

			if handler is None:
				continue

			brick_event = handler(user, target, config, last_damage_dealt)

			if brick_event is None:
				continue

			if brick_type == "dmg":
				last_damage_dealt = brick_event.get("damage", 0)

			events.append(brick_event)

		# ======================
		# 5. COOLDOWN
		# ======================
		self.trigger_cooldown()

		# ======================
		# 6. RETURN LOG
		# ======================
		return {
			"type": "skill",
			"skill": self.name,
			"actor": user.name,
			"target": target.name if target else None,
			"events": events
		}

	# ======================
	# BRICK RESOLUTION HELPERS
	# ======================

	def _resolve_target(self, brick_type, config, user, target, status_name=None):

		explicit = config.get("target")

		if explicit == "self":
			return user
		if explicit == "target":
			return target

		if brick_type == "apply_status" and status_name in STATUS_SELF_DEFAULT:
			return user

		default = DEFAULT_BRICK_TARGET.get(brick_type, "target")
		return user if default == "self" else target

	# ======================
	# BRICK: dmg
	# ======================

	def _brick_dmg(self, user, target, config, last_damage_dealt):

		dest = self._resolve_target("dmg", config, user, target)

		mult = config.get("mult", 1.0)
		use_crit = config.get("use_crit", True)
		ignore_defense = config.get("ignore_defense", False)

		is_crit = False

		if use_crit:
			crit_rate = user.get_crit_rate()
			is_crit = random.random() < crit_rate

			if is_crit:
				roll_mult = 1.8
			else:
				roll = random.random()
				if roll < 0.10:
					roll_mult = 0.8
				elif roll < 0.30:
					roll_mult = 0.9
				elif roll < 0.65:
					roll_mult = 1.0
				elif roll < 0.85:
					roll_mult = 1.1
				else:
					roll_mult = 1.2

			final_mult = mult * roll_mult
		else:
			final_mult = mult

		damage = user.get_base_damage() * final_mult

		damage_reduced = False

		if not ignore_defense and dest.has_status("defense") and not is_crit:
			damage *= dest.status["defense"]["def_rate"]
			damage_reduced = True

		damage = int(damage)

		result = dest.take_damage(damage)

		return {
			"type": "dmg",
			"attacker": user.name,
			"target": dest.name,
			"damage": damage,
			"crit": is_crit,
			"damage_reduced": damage_reduced,
			"target_alive": result["alive"],
			"remaining_hp": result["remaining_hp"]
		}

	# ======================
	# BRICK: recoil
	# ======================

	def _brick_recoil(self, user, target, config, last_damage_dealt):

		dest = self._resolve_target("recoil", config, user, target)

		amount = config.get("amount")

		if amount is None:
			percent = config.get("percent_of_dmg", 0)
			amount = last_damage_dealt * percent

		amount = int(amount)

		result = dest.take_damage(amount)

		return {
			"type": "recoil",
			"actor": user.name,
			"target": dest.name,
			"damage": amount,
			"target_alive": result["alive"],
			"remaining_hp": result["remaining_hp"]
		}

	# ======================
	# BRICK: heal
	# ======================

	def _brick_heal(self, user, target, config, last_damage_dealt):

		dest = self._resolve_target("heal", config, user, target)

		amount = config.get("amount")

		if amount is None:
			percent = config.get("percent_of_dmg", 0)
			amount = last_damage_dealt * percent

		result = dest.heal(amount)

		return {
			"type": "heal",
			"actor": user.name,
			"target": dest.name,
			"value": result["healed"],
			"remaining_hp": result["remaining_hp"]
		}

	# ======================
	# BRICK: affect_stat
	# ======================

	def _brick_affect_stat(self, user, target, config, last_damage_dealt):

		dest = self._resolve_target("affect_stat", config, user, target)

		stat = config.get("stat", "base_dmg")
		direction = config.get("type", "positive")
		level = config.get("level", 1)

		mult = AFFECT_STAT_LEVELS.get(level, 1.5)

		if direction == "negative":
			mult = 1 / mult

		dest.apply_stat_modifier(stat, mult)

		return {
			"type": "affect_stat",
			"actor": user.name,
			"target": dest.name,
			"stat": stat,
			"direction": direction,
			"level": level,
			"new_modifier": dest.get_stat_modifier(stat)
		}

	# ======================
	# BRICK: apply_status
	# ======================

	def _brick_apply_status(self, user, target, config, last_damage_dealt):

		status_name = config.get("status")

		if status_name is None:
			return None

		dest = self._resolve_target("apply_status", config, user, target, status_name=status_name)

		if dest.has_status(status_name):
			return {
				"type": "fail",
				"reason": "already_" + status_name,
				"target": dest.name
			}

		# Build the status payload from whichever keys are relevant.
		# Unused keys are simply absent from the config and ignored.
		payload = {}

		for key in ("turns", "def_rate", "blind_rate", "damage", "growth"):
			if key in config:
				payload[key] = config[key]

		dest.apply_status(status_name, payload)

		return {
			"type": "status",
			"status": status_name,
			"actor": user.name,
			"target": dest.name
		}

	# ======================
	# BRICK: remove_status
	# ======================

	def _brick_remove_status(self, user, target, config, last_damage_dealt):

		status_name = config.get("status")

		if status_name is None:
			return None

		dest = self._resolve_target("remove_status", config, user, target)

		had_it = dest.has_status(status_name)

		dest.remove_status(status_name)

		return {
			"type": "remove_status",
			"status": status_name,
			"actor": user.name,
			"target": dest.name,
			"removed": had_it
		}
