from entities.fighter import Fighter


class Player(Fighter):
	def __init__(self, name, archetype, skills):

		# Player no longer builds its own skills: entities/ must never depend
		# on factories/ (that's what caused the entities <-> factories import
		# cycle). Skills are built by ArchetypeFactory and handed over ready.
		super().__init__(
			name=name,
			entity_type="player",

			pvmax=archetype.pvmax,
			base_dmg=archetype.base_dmg,
			base_crit=archetype.crit_rate,
			base_accuracy=archetype.base_accuracy,

			skills=skills
		)

		self.archetype = archetype

		self.lvl = 1
		self.xp = 0

	def xp_to_next_level(self):
		return 100

	def get_xp_progress(self):
		return self.xp / self.xp_to_next_level()

	def add_xp(self, amount):
		self.xp += amount
		lvlup = self.xp // 100
		self.xp = self.xp % 100

		if lvlup > 0:
			self.add_lvl(lvlup)

		return lvlup

	def add_lvl(self, amount):
		for _ in range(amount):
			self.lvl += 1
			self.base_dmg += 2
			self.pvmax += 8

		self.pv = self.pvmax

	def make_rest(self):

		events = []

		# ======================
		# 1. FULL HP RESTORE
		# ======================
		self.pv = self.pvmax

		events.append({
			"type": "rest_full_heal",
			"target": self.name,
			"remaining_hp": self.pv
		})

		# ======================
		# 2. CLEAR ALL STATUS
		# ======================
		for status in list(self.status.keys()):
			events.append({
				"type": "status_cleared",
				"status": status,
				"target": self.name
			})

		self.status.clear()

		# ======================
		# 3. CLEAR STAT MODIFIERS (affect_stat is permanent for combat only)
		# ======================
		if self.stat_modifiers:
			events.append({
				"type": "stat_modifiers_cleared",
				"target": self.name
			})

		self.clear_stat_modifiers()

		# ======================
		# 4. RESET SKILL COOLDOWNS
		# ======================
		for skill in self.skills.values():
			skill.current_cooldown = 0

		events.append({
			"type": "cooldowns_reset",
			"target": self.name
		})

		# ======================
		# 5. RESET CORE STATE (SAFE)
		# ======================
		self.is_alive = True

		# ======================
		# 6. RETURN LOG
		# ======================
		return {
			"type": "rest",
			"actor": self.name,
			"events": events
		}
