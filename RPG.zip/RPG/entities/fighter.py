import random


class Fighter:

	def __init__(self, name, pvmax, base_dmg, base_crit, entity_type, base_accuracy=0.9, skills=None):

		# ======================
		# IDENTITY
		# ======================
		self.name = name
		self.entity_type = entity_type

		# ======================
		# STATS (BASE - NEVER MUTATED DIRECTLY BY EFFECTS)
		# ======================
		self.pvmax = pvmax
		self.pv = pvmax

		self.base_dmg = base_dmg
		self.base_crit = base_crit
		self.base_accuracy = base_accuracy

		# ======================
		# SKILLS
		# ======================
		# dict[str, Skill] -> one dedicated instance per Fighter (cooldowns are
		# never shared between two Fighters using "the same" skill).
		self.skills = skills or {}

		# ======================
		# STATE SYSTEM
		# ======================
		self.status = {}

		# ======================
		# STAT MODIFIERS (affect_stat brick)
		# ======================
		# Cumulative multipliers applied on top of base_dmg / base_crit / etc.
		# Permanent for the duration of the combat, cleared on rest.
		# Example: {"base_dmg": 1.5, "base_crit": 1.0}
		self.stat_modifiers = {}

		self.is_alive = True

	# ======================
	# STATUS SYSTEM
	# ======================

	def apply_status(self, name, data):
		self.status[name] = data

	def remove_status(self, name):
		self.status.pop(name, None)

	def has_status(self, name):
		return name in self.status

	# ======================
	# STAT MODIFIERS SYSTEM (affect_stat brick support)
	# ======================

	def get_stat_modifier(self, stat):
		return self.stat_modifiers.get(stat, 1.0)

	def apply_stat_modifier(self, stat, mult):
		"""Stacks a multiplier on top of any existing modifier for that stat."""
		current = self.stat_modifiers.get(stat, 1.0)
		self.stat_modifiers[stat] = current * mult

	def clear_stat_modifiers(self):
		self.stat_modifiers.clear()

	# ======================
	# DAMAGE SYSTEM
	# ======================

	def take_damage(self, damage):

		# DEFENSE REDUCTION
		if "defense" in self.status:
			damage *= self.status["defense"]["def_rate"]

		damage = int(damage)

		self.pv -= damage

		if self.pv <= 0:
			self.pv = 0
			self.is_alive = False

		return {
			"alive": self.is_alive,
			"remaining_hp": self.pv,
			"damage_taken": damage
		}

	def heal(self, amount):

		amount = int(amount)

		self.pv += amount

		if self.pv > self.pvmax:
			self.pv = self.pvmax

		return {
			"remaining_hp": self.pv,
			"healed": amount
		}

	# ======================
	# STATS (with stat_modifiers applied)
	# ======================

	def get_base_damage(self):
		return self.base_dmg * self.get_stat_modifier("base_dmg")

	def get_crit_rate(self):
		return self.base_crit * self.get_stat_modifier("base_crit")

	# ======================
	# ACCURACY SYSTEM
	# ======================

	def calculate_accuracy(self):

		accuracy = self.base_accuracy

		if "blind" in self.status:
			accuracy *= self.status["blind"]["blind_rate"]

		return random.random() < accuracy

	# ======================
	# MAIN TICK SYSTEM
	# ======================

	def tick(self):

		events = []

		# SKILL COOLDOWNS
		for skill in self.skills.values():
			skill.tick()

		# POISON
		if "poison" in self.status:

			p = self.status["poison"]

			self.pv -= p["damage"]

			events.append({
				"type": "poison_tick",
				"target": self.name,
				"value": p["damage"]
			})

			p["damage"] += p.get("growth", 0)

		# BURN
		if "burn" in self.status:

			b = self.status["burn"]

			self.pv -= b["damage"]

			events.append({
				"type": "burn_tick",
				"target": self.name,
				"value": b["damage"]
			})

		# BLIND
		if "blind" in self.status:

			bl = self.status["blind"]
			bl["turns"] -= 1

			if bl["turns"] <= 0:
				self.remove_status("blind")

				events.append({
					"type": "blind_end",
					"target": self.name
				})

		# DEFENSE
		if "defense" in self.status:

			d = self.status["defense"]
			d["turns"] -= 1

			if d["turns"] <= 0:
				self.remove_status("defense")

				events.append({
					"type": "defense_end",
					"target": self.name
				})

		# DEATH CHECK
		if self.pv <= 0 and self.is_alive:

			self.is_alive = False

			events.append({
				"type": "death",
				"target": self.name
			})

		return events
