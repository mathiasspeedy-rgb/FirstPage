class CombatUI:

	def __init__(self, ui):
		self.ui = ui

	# ======================
	# GET ACTION (returns the Skill object itself)
	# ======================
	# Useful when the caller wants to act on the skill directly
	# (e.g. a future "skill_in_fight" system that orchestrates usage).
	def get_action(self, player, target):

		while True:

			# ======================
			# HEADER
			# ======================
			self.ui.title("ACTIONS")

			# ======================
			# DISPLAY SKILLS
			# ======================
			skills = list(player.skills.values())

			for i, skill in enumerate(skills):

				cd = skill.current_cooldown

				if cd > 0:
					self.ui.write(f"{i}. {skill.name} (CD: {cd})", center=False)
				else:
					self.ui.write(f"{i}. {skill.name}", center=False)

			self.ui.blank()

			# ======================
			# INPUT
			# ======================
			choice = input("> ")

			if not choice.isdigit():
				self.ui.write("Choix invalide", center=False)
				self.ui.blank()
				continue

			choice = int(choice)

			if choice < 0 or choice >= len(skills):
				self.ui.write("Choix invalide", center=False)
				self.ui.blank()
				continue

			skill = skills[choice]

			# ======================
			# VALIDATION SKILL
			# ======================
			ok, reason = skill.can_use(player, target)

			if not ok:
				self.ui.write(reason, center=False)
				self.ui.write("Veuillez essayer une autre action", center=False)
				self.ui.blank()
				continue

			# ======================
			# RETURN VALID SKILL OBJECT
			# ======================
			return skill

	# ======================
	# GET ACTION NAME (returns the skill's name as a string)
	# ======================
	# Independent loop (not a wrapper around get_action) so each method can
	# evolve on its own. Used by game_loop.py, since Engine.fight(action)
	# expects a string key into player.skills.
	def get_action_name(self, player, target):

		while True:

			# ======================
			# HEADER
			# ======================
			self.ui.title("ACTIONS")

			# ======================
			# DISPLAY SKILLS
			# ======================
			skills = list(player.skills.values())

			for i, skill in enumerate(skills):

				cd = skill.current_cooldown

				if cd > 0:
					self.ui.write(f"{i}. {skill.name} (CD: {cd})", center=False)
				else:
					self.ui.write(f"{i}. {skill.name}", center=False)

			self.ui.blank()

			# ======================
			# INPUT
			# ======================
			choice = input("> ")

			if not choice.isdigit():
				self.ui.write("Choix invalide", center=False)
				self.ui.blank()
				continue

			choice = int(choice)

			if choice < 0 or choice >= len(skills):
				self.ui.write("Choix invalide", center=False)
				self.ui.blank()
				continue

			skill = skills[choice]

			# ======================
			# VALIDATION SKILL
			# ======================
			ok, reason = skill.can_use(player, target)

			if not ok:
				self.ui.write(reason, center=False)
				self.ui.write("Veuillez essayer une autre action", center=False)
				self.ui.blank()
				continue

			# ======================
			# RETURN VALID ACTION NAME
			# ======================
			# The key in player.skills may differ from skill.name (e.g. the
			# dict key is "attack" but skill.name is "Etranglement"), and
			# Engine.fight() looks up by dict key, so we resolve it here.
			for key, candidate in player.skills.items():
				if candidate is skill:
					return key

			return skill.name

	# ======================
	# RENDER FIGHT LOG (reads the raw Engine.fight() log format directly)
	# ======================
	def render_fight_log(self, combat_result):

		self.ui.separator()

		player_log = combat_result.get("player", {})
		enemy_log = combat_result.get("enemy", {})

		self._render_actor_log("Vous", player_log)
		self._render_actor_log(combat_result.get("enemy_type", "Ennemi").capitalize(), enemy_log)

		for event in combat_result.get("events", []):
			self._render_tick_event(event)

		self.ui.separator()

	def _render_actor_log(self, actor_label, log):

		log_type = log.get("type")

		if log_type is None:
			return

		if log_type == "fail":
			reason = log.get("reason", "")
			self.ui.write(f"{actor_label}: action échouée ({reason})", center=False)
			return

		if log_type == "miss":
			self.ui.write(f"{actor_label}: l'attaque rate sa cible", center=False)
			return

		if log_type == "skill":
			for event in log.get("events", []):
				self._render_brick_event(actor_label, event)
			return

	def _render_brick_event(self, actor_label, event):

		etype = event.get("type")

		if etype == "dmg":
			msg = f"{actor_label} infligent {event['damage']} dégâts à {event['target']}"
			if event.get("crit"):
				msg += " (CRITIQUE !)"
			if event.get("damage_reduced"):
				msg += " (réduit)"
			self.ui.write(msg, center=False)

			if not event.get("target_alive", True):
				self.ui.write(f"{event['target']} est vaincu !", center=False)

		elif etype == "heal":
			self.ui.write(f"{actor_label} soignent {event['target']} de {event['value']} PV", center=False)

		elif etype == "recoil":
			self.ui.write(f"{actor_label} subissent {event['damage']} dégâts de recul", center=False)

		elif etype == "status":
			self.ui.write(f"{actor_label} appliquent {event['status']} sur {event['target']}", center=False)

		elif etype == "remove_status":
			if event.get("removed"):
				self.ui.write(f"{event['status']} retiré de {event['target']}", center=False)

		elif etype == "affect_stat":
			self.ui.write(f"{event['target']}: {event['stat']} modifié ({event['direction']})", center=False)

		elif etype == "fail":
			self.ui.write(f"Effet manqué sur {event.get('target', '')} ({event.get('reason', '')})", center=False)

	def _render_tick_event(self, event):

		etype = event.get("type")

		if etype == "poison_tick":
			self.ui.write(f"{event['target']} subit {event['value']} dégâts de poison", center=False)

		elif etype == "burn_tick":
			self.ui.write(f"{event['target']} subit {event['value']} dégâts de brûlure", center=False)

		elif etype == "blind_end":
			self.ui.write(f"{event['target']} n'est plus aveuglé", center=False)

		elif etype == "defense_end":
			self.ui.write(f"{event['target']} n'est plus en défense", center=False)

		elif etype == "death":
			self.ui.write(f"{event['target']} succombe", center=False)

	# ======================
	# RENDER REWARD LOG
	# ======================
	def render_reward_log(self, game_result):

		self.ui.separator()

		xp = game_result.get("xp", 0)
		lvl_up = game_result.get("lvl_up", 0)

		self.ui.write(f"XP gagné : {xp}", center=False)

		if lvl_up > 0:
			self.ui.write(f"Niveau supérieur ! (+{lvl_up})", center=False)

		if game_result.get("tier_advanced"):
			self.ui.write(f"Palier suivant débloqué : {game_result.get('new_tier')}", center=False)
			tier_intro = game_result.get("tier_intro")
			if tier_intro:
				self.ui.write(tier_intro, center=False)

		if game_result.get("last_tier_over"):
			self.ui.write("Vous avez vaincu le dernier gardien de l'Abyss.", center=False)

		self.ui.separator()
