INSERT INTO skill(name_skill,description_skill) VALUES 

--ARES
------

('Lance Sangleante',
'Projette une lance maudite qui inflige de lourds degats et provoque un saignement durable'
),

('Massacre Divin',
'Dechaine la fureur du dieu de la guerre et frappe avec une puissance devastatrice'
),

-- ATHENA

('Frappe Calculée',
'Execute une attaque precise qui exploite les faiblesses de la cible'
),

('Dernier Jugement',
'Rend un verdict implacable et inflige une punition proportionnelle aux erreurs de lennemi'
),

-- PROMETEE

('Flamme Volée',
'Utilise le feu sacre derobe aux dieux pour embraser la cible'
),

('Feu Interdit',
'Libere une flamme divine instable qui consume tout sur son passage'
),

('Chatiment du Titan',
'Invoque la colere de Prometee et ecrase lennemi sous une puissance titanesque'
),

-- APOLLON

('Flèche de Soleil',
'Tire une fleche baignee de lumiere solaire qui transperce les defenses'
),

('Lumière Vitale',
'Canalise la puissance du soleil afin de restaurer une partie de la vitalite'
),

('Apothéose',
'Atteint un etat divin temporaire qui amplifie enormement la puissance de combat'
),

-- ATLAS

('Poing du Titan',
'Frappe avec une force colossale capable de faire trembler la terre'
),

('Pilier du Monde',
'Renforce son corps par le poids du monde et augmente sa resistance'
),

('Effondrement Célèste',
'Declenche un cataclysme qui ecrase les ennemis sous une pression gigantesque'
),

-- PERSEPHONE

('Epine Maudite',
'Projette une epine empoisonnee qui infecte progressivement sa victime'
),

('Miasme du Tartare',
'Repand un nuage toxique qui affaiblit et empoisonne tous ceux qui le respirent'
),

('Hiver des Morts',
'Recouvre le champ de bataille dune energie funeraire qui ronge lentement la vie'
),

-- Hadès

('Siphon Infernal',
'Absorbe une partie de la vitalite de la cible afin de restaurer ses propres forces'
),

('Drain des Enfers',
'Puise directement dans l ame de lennemi et convertit cette energie en regeneration'
),

('Sentence Mortelle',
'Prononce le jugement final et inflige une attaque capable de condamner les plus faibles'
),

-- OUROBOROS

('Constrictor',
'Enserre sa proie dans une pression grandissante qui devient plus dangereuse avec le temps'
),

('Cycle Infini',
'Declenche une boucle eternelle qui restaure progressivement ses forces'
),

('Dévoration Cosmique',
'Consume la matiere et l energie environnantes pour accroître sa puissance'
),

-- CHAOS

('Fragmentation',
'Brise la structure de la cible et provoque des degats instables'
),

('Incandescence',
'Declenche une combustion anarchique qui inflige des degats continus'
),

('Genesis',
'Reecrit les lois du vivant afin de regenerer massivement son utilisateur'
),

('Paradoxe',
'Inverse les logiques du combat et produit un effet impossible a anticiper'
),

('Décomposition',
'Accelere la degradation du corps et de lesprit de la cible'
),

('Assimilation',
'Absorbe une partie des attributs de lennemi pour renforcer son utilisateur'
),

('Noir Absolu',
'Plonge la cible dans une obscurite totale et reduit fortement sa precision'
),

('Instabilité',
'Corrompt la realite et provoque des effets aleatoires sur le champ de bataille'
),

('Apocalypse',
'Libere le pouvoir ultime du Chaos et inflige une destruction cataclysmique'
);