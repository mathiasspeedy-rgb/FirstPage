INSERT INTO brik(name_brik,type_brik,target_brik,description_brik)
VALUES 

('attack',
'dmg',
'target',
'make damage to target'),

('recoil',
'dmg',
'self',
'make damage to himself'),

('self_heal',
'heal',
'self',
'make heal to himself'),

('other_heal',
'heal',
'target',
'make heal to target'),

('apply_status',
'status',
'target',
'give status to target'),

('get_status',
'status',
'self',
'give_status to himself')