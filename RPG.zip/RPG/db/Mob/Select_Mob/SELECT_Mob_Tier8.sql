SELECT G.id_character,F.id_fighter,M.id_mob,G.character_name,M.tier_mob
FROM mob M LEFT JOIN fighter_character F ON M.id_fighter = F.id_fighter LEFT JOIN game_character G ON G.id_character = F.id_character
WHERE M.tier_mob = 8