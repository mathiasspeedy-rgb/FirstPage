INSERT INTO 
game_character (character_name,character_description)

VALUES 
(
	'Colosse Sismique',
	'Creature titanesque dont chaque pas provoque des tremblements devastateurs. Le terrain devient une arme a chaque mouvement'
),

(
	'Golem de Plaques',
	'Entite forme de plaques rocheuses vivantes. Sa structure change lentement sous la pression du monde'
),

(
	'Tortue du Monde',
	'Creature ancestrale portant une partie du monde sur son dos. Sa defense est presque impossible a briser'
),

(
	'Limace Gravitationnelle',
	'Creature lente qui modifie la gravite autour delle. Tout devient plus lourd a son contact'
),

(
	'Roc Abyssal',
	'Fragment vivant des profondeurs du monde. Son poids ecrase tout ce qui se trouve a proximite'
),

(
	'Mammouth de Granit',
	'Bete ancienne recouverte de pierre vivante. Sa charge est lente mais detruit tout sur son passage'
);

---------------------------

INSERT INTO fighter_character(id_character)

(SELECT G.id_character
FROM game_character G
WHERE G.character_name IN (
	'Colosse Sismique',
	'Golem de Plaques',
	'Tortue du Monde',
	'Limace Gravitationnelle',
	'Roc Abyssal',
	'Mammouth de Granit'
));

---------------------------

INSERT INTO mob(id_fighter)

(SELECT F.id_fighter
FROM fighter_character F 
LEFT JOIN game_character G ON G.id_character = F.id_character
WHERE G.character_name IN (
	'Colosse Sismique',
	'Golem de Plaques',
	'Tortue du Monde',
	'Limace Gravitationnelle',
	'Roc Abyssal',
	'Mammouth de Granit'
));

-----------------------------

UPDATE mob
SET tier_mob = 5
WHERE id_mob IN (
	SELECT M.id_mob
	FROM mob M 
	LEFT JOIN fighter_character F ON M.id_fighter = F.id_fighter 
	LEFT JOIN game_character G ON F.id_character = G.id_character
	WHERE G.character_name IN (
		'Colosse Sismique',
		'Golem de Plaques',
		'Tortue du Monde',
		'Limace Gravitationnelle',
		'Roc Abyssal',
		'Mammouth de Granit'
	)
);