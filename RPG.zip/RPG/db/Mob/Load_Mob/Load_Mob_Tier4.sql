INSERT INTO 
game_character (character_name,character_description)

VALUES 
(
	'Archonte Solaire',
	'Gardien de la lumiere divine. Il impose une presence solaire qui punit toute erreur par des brulures sacrees'
),

(
	'Avatar Photique',
	'Forme pure de lumiere vivante. Son corps est une emanation du soleil et regenere constamment dans la radiance'
),

(
	'Basilic Blanc',
	'Creature serpentine dont le regard amplifie la lumiere au point de bruler la vie elle meme'
),

(
	'Cerf Ecliptique',
	'Bete rapide qui alterne entre ombre et lumiere solaire. Ses mouvements sont impossibles a anticiper'
),

(
	'Nymphe Corrompue',
	'Esprit de la nature touche par une lumiere excessive. Elle transforme la vitalite en energie instable'
),

(
	'Lamproie de la Nature',
	'Creature parasite des eaux et des racines. Elle absorbe la vie et la convertit en chaleur solaire'
);

---------------------------

INSERT INTO fighter_character(id_character)

(SELECT G.id_character
FROM game_character G
WHERE G.character_name IN (
	'Archonte Solaire',
	'Avatar Photique',
	'Basilic Blanc',
	'Cerf Ecliptique',
	'Nymphe Corrompue',
	'Lamproie de la Nature'
));

---------------------------

INSERT INTO mob(id_fighter)

(SELECT F.id_fighter
FROM fighter_character F 
LEFT JOIN game_character G ON G.id_character = F.id_character
WHERE G.character_name IN (
	'Archonte Solaire',
	'Avatar Photique',
	'Basilic Blanc',
	'Cerf Ecliptique',
	'Nymphe Corrompue',
	'Lamproie de la Nature'
));

-----------------------------

UPDATE mob
SET tier_mob = 4
WHERE id_mob IN (
	SELECT M.id_mob
	FROM mob M 
	LEFT JOIN fighter_character F ON M.id_fighter = F.id_fighter 
	LEFT JOIN game_character G ON F.id_character = G.id_character
	WHERE G.character_name IN (
		'Archonte Solaire',
		'Avatar Photique',
		'Basilic Blanc',
		'Cerf Ecliptique',
		'Nymphe Corrompue',
		'Lamproie de la Nature'
	)
);