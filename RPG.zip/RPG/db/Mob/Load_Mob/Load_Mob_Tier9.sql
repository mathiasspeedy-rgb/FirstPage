INSERT INTO 
game_character (character_name,character_description)

VALUES 
(
	'Typhon',
	'Creature primordiale chaotique dont la puissance evolue constamment au fil du combat et ne peut etre contenue'
),

(
	'Jormungandr',
	'Serpent mondial qui entoure le monde. Sa presence amplifie les cycles de destruction et de renaissance'
),

(
	'Hydre de Lerne',
	'Creature regenerative dont les blessures provoquent une evolution constante de ses capacites offensives'
),

(
	'Serpent Celeste',
	'Entite reptilienne divine qui traverse les cycles du temps et adapte sa puissance a toute forme de menace'
),

(
	'Apep',
	'Serpent du chaos eternel qui attaque sans fin le soleil et renait de chaque defaite'
),

(
	'Ladon',
	'Dragon gardien evolutif qui protege les fruits divins et devient plus puissant a chaque intrusion'
);

---------------------------

INSERT INTO fighter_character(id_character)

(SELECT G.id_character
FROM game_character G
WHERE G.character_name IN (
	'Typhon',
	'Jormungandr',
	'Hydre de Lerne',
	'Serpent Celeste',
	'Apep',
	'Ladon'
));

---------------------------

INSERT INTO mob(id_fighter)

(SELECT F.id_fighter
FROM fighter_character F 
LEFT JOIN game_character G ON G.id_character = F.id_character
WHERE G.character_name IN (
	'Typhon',
	'Jormungandr',
	'Hydre de Lerne',
	'Serpent Celeste',
	'Apep',
	'Ladon'
));

-----------------------------

UPDATE mob
SET tier_mob = 9
WHERE id_mob IN (
	SELECT M.id_mob
	FROM mob M 
	LEFT JOIN fighter_character F ON M.id_fighter = F.id_fighter 
	LEFT JOIN game_character G ON F.id_character = G.id_character
	WHERE G.character_name IN (
		'Typhon',
		'Jormungandr',
		'Hydre de Lerne',
		'Serpent Celeste',
		'Apep',
		'Ladon'
	)
);