INSERT INTO 
game_character (character_name,character_description)

VALUES 
(
	'Golem Egide',
	'Statue vivante forgée pour le combat. Il adapte ses coups à chaque attaque pour devenir presque imprenable'

),

(
	'Griffon de Stratégie',
	'Prédateur céleste qui analyse le champs de bataille avant de se mettre à attaquer. Chaque mouvement est optimisé pour exploiter une faiblesse'

),

(
	'Champion de la Raison',
	'Créature disciplinée incarnant la guerre logique. Il contre-attaque uniquement quand la victoire est garantie'

),


(
	'Paladin Déchu',
	'Ancien gardien de la sagesse tombé dans une logique froide de destruction. Il ne protège plus, il execute'

),

(
	'Hibou Souverain',
	'Créature de vision absolue. Il observe tout le combat et anticipe les actions des combatants'

),

(
	'Epeiste Algorithmique',
	'Monstre qui apprend calcule chaque mouvement adverse. Plus le combat dure, plus il devient efficace'

)

---------------------------

INSERT INTO fighter_character(id_character)

(SELECT (G.id_character)
FROM game_character G

WHERE G.character_name IN ('Golem Egide','Griffon de Stratégie','Champion de la Raison','Paladin Déchu','Hibou Souverain','Epeiste Algorithmique')
);
---------------------------

INSERT INTO mob(id_fighter)

(SELECT F.id_fighter
FROM fighter_character F LEFT JOIN game_character G ON G.id_character = F.id_character
WHERE  G.character_name IN ('Golem Egide','Griffon de Stratégie','Champion de la Raison','Paladin Déchu','Hibou Souverain','Epeiste Algorithmique')

);
-----------------------------

UPDATE mob
SET tier_mob = 2
WHERE 
id_mob IN
(SELECT M.id_mob
FROM mob M LEFT JOIN fighter_character F ON M.id_fighter = F.id_fighter 
LEFT JOIN game_character G ON F.id_character = G.id_character
WHERE G.character_name IN ('Golem Egide','Griffon de Stratégie','Champion de la Raison','Paladin Déchu','Hibou Souverain','Epeiste Algorithmique')
)





