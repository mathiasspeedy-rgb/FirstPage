INSERT INTO 
game_character (character_name,character_description)

VALUES 
(
	'Vestige Incandescent',
	'Reste vivant dun etre touche par le feu divin. Son corps continue de bruler et repand une chaleur sacree instable'
),

(
	'Chimere du Savoir Brule',
	'Creature nee dexperiences interdites. Elle incarne un savoir divin incomplet qui consume tout ce quil touche'
),

(
	'Forge Vivante',
	'Entite de metal et de feu animee par une energie divine. Elle transforme toute attaque en brasier destructeur'
),

(
	'Ecorche Pyrotechnique',
	'Monstre dont la chair est en combustion permanente. Sa douleur est une source de puissance brutale'
),

(
	'Phenix Defectueux',
	'Creature de renaissance imparfaite. Chaque mort renforce son instabilite et sa violence'
),

(
	'Golem de Lave',
	'Colosse ne des profondeurs en fusion. Il avance lentement mais detruit tout sur son passage'
);

---------------------------

INSERT INTO fighter_character(id_character)

(SELECT G.id_character
FROM game_character G
WHERE G.character_name IN (
	'Vestige Incandescent',
	'Chimere du Savoir Brule',
	'Forge Vivante',
	'Ecorche Pyrotechnique',
	'Phenix Defectueux',
	'Golem de Lave'
));

---------------------------

INSERT INTO mob(id_fighter)

(SELECT F.id_fighter
FROM fighter_character F 
LEFT JOIN game_character G ON G.id_character = F.id_character
WHERE G.character_name IN (
	'Vestige Incandescent',
	'Chimere du Savoir Brule',
	'Forge Vivante',
	'Ecorche Pyrotechnique',
	'Phenix Defectueux',
	'Golem de Lave'
));

-----------------------------

UPDATE mob
SET tier_mob = 3
WHERE id_mob IN (
	SELECT M.id_mob
	FROM mob M 
	LEFT JOIN fighter_character F ON M.id_fighter = F.id_fighter 
	LEFT JOIN game_character G ON F.id_character = G.id_character
	WHERE G.character_name IN (
		'Vestige Incandescent',
		'Chimere du Savoir Brule',
		'Forge Vivante',
		'Ecorche Pyrotechnique',
		'Phenix Defectueux',
		'Golem de Lave'
	)
);