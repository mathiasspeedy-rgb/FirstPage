INSERT INTO 
game_character (character_name,character_description)

VALUES 
(
	'Moissonneur d Ame',
	'Entite des enfers qui ne blesse pas le corps mais arrache directement la vitalite de l ennemi pour se regenerer'
),

(
	'Cerbere Chien des Enfers',
	'Gardien a trois têtes des portes de la mort. Il draine la force vitale de ceux qui tentent de fuir les enfers'
),

(
	'Ombre Primordiale',
	'Fragment de non vie pure qui absorbe l energie vitale de toute creature proche pour se maintenir'
),

(
	'Hippolyte Cheval des Enfers',
	'Monture spectrale qui traverse les champs de bataille en volant la vitalite des ennemis sur son passage'
),

(
	'Minotaure',
	'Creature de violence enfermee dans le labyrinthe. Plus elle inflige de degats plus elle recupere de vitalite'
),

(
	'Sucube',
	'Entite seductrice des enfers qui se nourrit de l energie vitale de ses victimes en combat rapproché'
);

---------------------------

INSERT INTO fighter_character(id_character)

(SELECT G.id_character
FROM game_character G
WHERE G.character_name IN (
	'Moissonneur d Ame',
	'Cerbere Chien des Enfers',
	'Ombre Primordiale',
	'Hippolyte Cheval des Enfers',
	'Minotaure',
	'Sucube'
));

---------------------------

INSERT INTO mob(id_fighter)

(SELECT F.id_fighter
FROM fighter_character F 
LEFT JOIN game_character G ON G.id_character = F.id_character
WHERE G.character_name IN (
	'Moissonneur d Ame',
	'Cerbere Chien des Enfers',
	'Ombre Primordiale',
	'Hippolyte Cheval des Enfers',
	'Minotaure',
	'Sucube'
));

-----------------------------

UPDATE mob
SET tier_mob = 7
WHERE id_mob IN (
	SELECT M.id_mob
	FROM mob M 
	LEFT JOIN fighter_character F ON M.id_fighter = F.id_fighter 
	LEFT JOIN game_character G ON F.id_character = G.id_character
	WHERE G.character_name IN (
		'Moissonneur d Ame',
		'Cerbere Chien des Enfers',
		'Ombre Primordiale',
		'Hippolyte Cheval des Enfers',
		'Minotaure',
		'Sucube'
	)
);