INSERT INTO 
game_character (character_name,character_description)

VALUES 
(
	'Ver Funeraire',
	'Creature souterraine qui consomme la vie en silence. Son corps libere un poison de putrefaction qui affaiblit progressivement les ennemis'
),

(
	'Orchidee Carnivore',
	'Plante mortelle qui attire ses proies avec son parfum. Son nectar est un poison qui paralyse avant de drainer la vie'
),

(
	'Papillon Necrose',
	'Insecte funebre dont les ailes liberent un pollen toxique accelerant la decomposition et la perte de vitalite'
),

(
	'Escargot Putrifiant',
	'Creature lente qui laisse une trace de boue toxique. Tout contact provoque un affaiblissement progressif du corps'
),

(
	'Fongus des Tombes',
	'Champignon parasite qui infecte le terrain avec des spores venimeuses et absorbe lentement l energie vitale'
),

(
	'Scarabee Sepulcral',
	'Insecte sacre des tombes qui transporte la corruption. Il injecte un venin qui degrade la resistance des corps'
);

---------------------------

INSERT INTO fighter_character(id_character)

(SELECT G.id_character
FROM game_character G
WHERE G.character_name IN (
	'Ver Funeraire',
	'Orchidee Carnivore',
	'Papillon Necrose',
	'Escargot Putrifiant',
	'Fongus des Tombes',
	'Scarabee Sepulcral'
));

---------------------------

INSERT INTO mob(id_fighter)

(SELECT F.id_fighter
FROM fighter_character F 
LEFT JOIN game_character G ON G.id_character = F.id_character
WHERE G.character_name IN (
	'Ver Funeraire',
	'Orchidee Carnivore',
	'Papillon Necrose',
	'Escargot Putrifiant',
	'Fongus des Tombes',
	'Scarabee Sepulcral'
));

-----------------------------

UPDATE mob
SET tier_mob = 6
WHERE id_mob IN (
	SELECT M.id_mob
	FROM mob M 
	LEFT JOIN fighter_character F ON M.id_fighter = F.id_fighter 
	LEFT JOIN game_character G ON F.id_character = G.id_character
	WHERE G.character_name IN (
		'Ver Funeraire',
		'Orchidee Carnivore',
		'Papillon Necrose',
		'Escargot Putrifiant',
		'Fongus des Tombes',
		'Scarabee Sepulcral'
	)
);