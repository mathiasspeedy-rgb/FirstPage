INSERT INTO 
game_character (character_name,character_description)

VALUES 
(
	'Echec Zero',
	'Entite qui ignore les lois de la probabilite. Toute action est force de reussir ou d echouer de maniere absolue et imprevisible'
),

(
	'Golem Cellulaire',
	'Organisme compose de cellules en evolution permanente. Sa structure se reconfigure en temps reel pour survivre'
),

(
	'Masse Proteique',
	'Entite biologique amorphe capable de copier et absorber les caracteristiques de toute forme de vie'
),

(
	'Virus Mythologique',
	'Agent infectieux qui corrompt les lois du combat et transforme les capacites ennemies en instabilite pure'
),

(
	'Anomalie',
	'Erreur vivante dans la realite. Elle perturbe les regles du monde et rend le combat imprevisible'
),

(
	'Voyageur du Temps',
	'Entite capable de modifier les lignes temporelles du combat et de reapparaitre avant chaque defaite'
);

---------------------------

INSERT INTO fighter_character(id_character)

(SELECT G.id_character
FROM game_character G
WHERE G.character_name IN (
	'Echec Zero',
	'Golem Cellulaire',
	'Masse Proteique',
	'Virus Mythologique',
	'Anomalie',
	'Voyageur du Temps'
));

---------------------------

INSERT INTO mob(id_fighter)

(SELECT F.id_fighter
FROM fighter_character F 
LEFT JOIN game_character G ON G.id_character = F.id_character
WHERE G.character_name IN (
	'Echec Zero',
	'Golem Cellulaire',
	'Masse Proteique',
	'Virus Mythologique',
	'Anomalie',
	'Voyageur du Temps'
));

-----------------------------

UPDATE mob
SET tier_mob = 10
WHERE id_mob IN (
	SELECT M.id_mob
	FROM mob M 
	LEFT JOIN fighter_character F ON M.id_fighter = F.id_fighter 
	LEFT JOIN game_character G ON F.id_character = G.id_character
	WHERE G.character_name IN (
		'Echec Zero',
		'Golem Cellulaire',
		'Masse Proteique',
		'Virus Mythologique',
		'Anomalie',
		'Voyageur du Temps'
	)
);