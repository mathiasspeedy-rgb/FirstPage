INSERT INTO 
game_character (character_name,character_description)

VALUES 
(
	'Scorpion des Sables',
	'Creature du desert qui attaque dans les tempetes de sable. Son venin perturbe la vision et la perception des ennemis'
),

(
	'Vautour du Chaos',
	'Oiseau du desert qui fond sur ses proies dans les tempetes. Il exploite la confusion et rend les combats imprévisibles'
),

(
	'Crocodile des Sables',
	'Predateur enfoui sous le sable qui attaque par surprise. Il manipule le terrain pour aveugler ses adversaires'
),

(
	'Sphinx',
	'Gardien des enigmes du desert. Ses illusions et ses questions perturbent la logique et la vision du combat'
),

(
	'Ammit',
	'Creature juge des ames qui devore les faibles. Elle apparait dans les mirages et punit instantanément les erreurs'
),

(
	'Enfant de Nyx',
	'Entite de la nuit primordiale qui plonge le champ de bataille dans l obscurite totale et coupe la vision des adversaires'
);

---------------------------

INSERT INTO fighter_character(id_character)

(SELECT G.id_character
FROM game_character G
WHERE G.character_name IN (
	'Scorpion des Sables',
	'Vautour du Chaos',
	'Crocodile des Sables',
	'Sphinx',
	'Ammit',
	'Enfant de Nyx'
));

---------------------------

INSERT INTO mob(id_fighter)

(SELECT F.id_fighter
FROM fighter_character F 
LEFT JOIN game_character G ON G.id_character = F.id_character
WHERE G.character_name IN (
	'Scorpion des Sables',
	'Vautour du Chaos',
	'Crocodile des Sables',
	'Sphinx',
	'Ammit',
	'Enfant de Nyx'
));

-----------------------------

UPDATE mob
SET tier_mob = 8
WHERE id_mob IN (
	SELECT M.id_mob
	FROM mob M 
	LEFT JOIN fighter_character F ON M.id_fighter = F.id_fighter 
	LEFT JOIN game_character G ON F.id_character = G.id_character
	WHERE G.character_name IN (
		'Scorpion des Sables',
		'Vautour du Chaos',
		'Crocodile des Sables',
		'Sphinx',
		'Ammit',
		'Enfant de Nyx'
	)
);