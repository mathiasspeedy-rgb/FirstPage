INSERT INTO 
game_character (character_name,character_description)

VALUES 
(
	'Chien de guerre',
	'Bête entrainée pour la traque et le combat. Il ne lâche jamais sa proie et attaque avec une violence instinctive'

),

(
	'Loup du Carnage',
	'Prédateur né au coeur des champs de bataille. Il se nourrit du chaos et devient plus agressif à chaqie blessure'

),

(
	'Taureaux Furieux',
	'Créature massive incarnant la charge brute et incontrolable. Quand il fonce, rien ne peut arrêter cette bête'

),


(
	'Kérès',
	'Esprit de mort attiré par les champs de bataille. Elle plane sur les combats et se combat aux plus faibles'

),

(
	'Harpie Sangleante',
	'Créature ailée sauvage, fondant sur ses victimes pour les lacérer. Elle dévore la douleur et le sang des vivants.'

),

(
	'Drako Guerrier',
	'Dragon reptilien formé par la guerre. Il combine sa puissance brute et instinct de destuction'

)

---------------------------

INSERT INTO fighter_character(id_character)

(SELECT (G.id_character)
FROM game_character G

WHERE G.character_name IN ('Chien de guerre','Loup du Carnage','Taureaux Furieux','Kérès','Harpie Sangleante','Drako Guerrier')
)
---------------------------

INSERT INTO mob(id_fighter)

(SELECT F.id_fighter
FROM fighter_character F LEFT JOIN game_character G ON G.id_character = F.id_character
WHERE  G.character_name IN ('Chien de guerre','Loup du Carnage','Taureaux Furieux','Kérès','Harpie Sangleante','Drako Guerrier')

)
-----------------------------

UPDATE mob
SET tier_mob = 1
WHERE 
id_mob IN
(SELECT M.id_mob
FROM mob M LEFT JOIN fighter_character F ON M.id_fighter = F.id_fighter 
LEFT JOIN game_character G ON F.id_character = G.id_character
WHERE  G.character_name IN ('Chien de guerre','Loup du Carnage','Taureaux Furieux','Kérès','Harpie Sangleante','Drako Guerrier')
)





