SELECT G.id_character,F.id_fighter,B.id_boss,G.character_name,B.tier_boss
FROM boss B LEFT JOIN fighter_character F ON B.id_fighter = F.id_fighter LEFT JOIN game_character G ON G.id_character = F.id_character
