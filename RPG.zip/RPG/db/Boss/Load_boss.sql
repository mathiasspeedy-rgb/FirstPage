INSERT INTO 
game_character (character_name,character_description)

VALUES 
(
	'Arès',
	'Dieu de la guerre dans sa forme la plus brutale. Chaque bataille nourrit sa soif de destruction et son désir de carnage.'

),

(
	'Athéna',
	'Déesse de la stratégie et de la sagesse guerrière. Ses coups frappent toujours là où ils sont les plus fort'

),

(
	'Prométée',
	'Le Titan qui vola le feu divin pour le donner aux mortels. Les flammes dont il possède le pouvoir sont un don devenu un chatiment éternel.'

),


(
	'Apollon',
	'Dieu du soleil, de la lumière et de la perfection. Sa radiance restaure son corpsmais peut également infliger de sérieux dégats'

),

(
	'Atlas',
	'Titan condamné à porter le monde sur ses épaules. Aucune force ne semble capable de surpasser sa résistance légendaire.'

),

(
	'Perséphone',
	'Reine des Enfers, elle fait éclore des fleurs aussi belles que mortelles. Son pouvoir se répand lentement, condamnant ses victimes à une agonie inévitable.'

),

(
	'Hadès',
	'Souverain des Enfers et gardiens des âmes perdues. Chaque vie que ce Dieu arrache renforce son emprise sur le royaume des morts.'

),

(
	'Seth',
	'Maitre des temête et du chaos du désert. Sous les sables maudits, la vue se trouble et la certitude disparait'
),

(
	'Ouroboros',
	'Le serpent qui se dévore lui-même dans un cycle sans fin. Chaque boucle, sa puissance grandit et devient impossible à arrêter'

),

(
	'Chaos',
	'Une entité primordiale dont sont né les dieux et les mondes. Il incarne toutes les forces de la création et de la destruction à la fois.'
);
---------------------------

INSERT INTO fighter_character(id_character)

(SELECT (G.id_character)
FROM game_character G

WHERE G.character_name IN ('Arès','Athéna','Prométée','Apollon','Atlas','Perséphone','Hadès','Seth','Ouroboros','Chaos');

---------------------------

INSERT INTO boss(id_fighter)

(SELECT F.id_fighter
FROM fighter_character F LEFT JOIN game_character G ON G.id_character = F.id_character
WHERE  G.character_name IN ('Arès','Athéna','Prométée','Apollon','Atlas','Perséphone','Hadès','Seth','Ouroboros','Chaos')

);
-----------------------------

UPDATE boss 
SET  tier_boss = 1
WHERE 
(boss.id_boss = 
(SELECT B.id_boss
FROM boss B LEFT JOIN fighter_character F ON B.id_fighter = F.id_fighter LEFT JOIN game_character G ON G.id_character = F.id_character
WHERE G.character_name = 'Arès')
);

UPDATE boss 
SET  tier_boss = 2
WHERE 
(boss.id_boss = 
(SELECT B.id_boss
FROM boss B LEFT JOIN fighter_character F ON B.id_fighter = F.id_fighter LEFT JOIN game_character G ON G.id_character = F.id_character
WHERE G.character_name = 'Athéna')
);

UPDATE boss 
SET  tier_boss = 3
WHERE 
(boss.id_boss = 
(SELECT B.id_boss
FROM boss B LEFT JOIN fighter_character F ON B.id_fighter = F.id_fighter LEFT JOIN game_character G ON G.id_character = F.id_character
WHERE G.character_name = 'Prométée')
);

UPDATE boss 
SET  tier_boss = 4
WHERE 
(boss.id_boss = 
(SELECT B.id_boss
FROM boss B LEFT JOIN fighter_character F ON B.id_fighter = F.id_fighter LEFT JOIN game_character G ON G.id_character = F.id_character
WHERE G.character_name = 'Apollon')
);

UPDATE boss 
SET  tier_boss = 5
WHERE 
(boss.id_boss = 
(SELECT B.id_boss
FROM boss B LEFT JOIN fighter_character F ON B.id_fighter = F.id_fighter LEFT JOIN game_character G ON G.id_character = F.id_character
WHERE G.character_name = 'Atlas')
);

UPDATE boss 
SET  tier_boss = 6
WHERE 
(boss.id_boss = 
(SELECT B.id_boss
FROM boss B LEFT JOIN fighter_character F ON B.id_fighter = F.id_fighter LEFT JOIN game_character G ON G.id_character = F.id_character
WHERE G.character_name = 'Perséphone')
);

UPDATE boss 
SET  tier_boss = 7
WHERE 
(boss.id_boss = 
(SELECT B.id_boss
FROM boss B LEFT JOIN fighter_character F ON B.id_fighter = F.id_fighter LEFT JOIN game_character G ON G.id_character = F.id_character
WHERE G.character_name = 'Hadès')
);

UPDATE boss 
SET  tier_boss = 8
WHERE 
(boss.id_boss = 
(SELECT B.id_boss
FROM boss B LEFT JOIN fighter_character F ON B.id_fighter = F.id_fighter LEFT JOIN game_character G ON G.id_character = F.id_character
WHERE G.character_name = 'Seth')
);

UPDATE boss 
SET  tier_boss = 9
WHERE 
(boss.id_boss = 
(SELECT B.id_boss
FROM boss B LEFT JOIN fighter_character F ON B.id_fighter = F.id_fighter LEFT JOIN game_character G ON G.id_character = F.id_character
WHERE G.character_name = 'Ouroboros')
);

UPDATE boss 
SET  tier_boss = 10
WHERE 
(boss.id_boss = 
(SELECT B.id_boss
FROM boss B LEFT JOIN fighter_character F ON B.id_fighter = F.id_fighter LEFT JOIN game_character G ON G.id_character = F.id_character
WHERE G.character_name = 'Chaos')
);



