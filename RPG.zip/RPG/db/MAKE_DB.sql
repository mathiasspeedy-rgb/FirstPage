-- CREATE DATABASE Mathias_Gonzalez_Gomez
-- DROP DATABASE Mathias_Gonzalez_Gomez

CREATE TABLE brik(
	id_brik INT PRIMARY KEY IDENTITY,
	name_brik VARCHAR(50),
	type_brik VARCHAR(50),
	target_brik VARCHAR(50),
	description_brik VARCHAR(500)
)

CREATE TABLE skill(
	id_skill INT PRIMARY KEY IDENTITY,
	name_skill VARCHAR(50),
	family_id VARCHAR(50),
	description_skill VARCHAR(500),
	lvl_skill INT
)

CREATE TABLE skill_brikset(
	id_skill INT UNIQUE NOT NULL
	CONSTRAINT FK_id_skill FOREIGN KEY (id_skill) REFERENCES skill(id_skill),

	id_brik INT UNIQUE NOT NULL
	CONSTRAINT FK_id_brik FOREIGN KEY (id_brik) REFERENCES brik(id_brik),

	order_brik INT,
	odd_brik FLOAT,
	value_brik FLOAT
)

CREATE TABLE game_character( 
	id_character INT PRIMARY KEY IDENTITY,
	character_name VARCHAR(50),
	character_description VARCHAR(500),
)

CREATE TABLE fighter_character(
	id_character INT UNIQUE NOT NULL
	CONSTRAINT Heritage_id_fighter FOREIGN KEY (id_character) REFERENCES game_character(id_character),
	id_fighter INT IDENTITY PRIMARY KEY,

	power_fighter INT,
	pv_max_fighter INT,
	crit_rate_fighter INT, -- sur 100
	precision_fighter INT, -- sur 100
	mana_max_fighter INT

)

CREATE TABLE skill_set(
	id_fighter INT UNIQUE NOT NULL
	CONSTRAINT FK_id_fighter_character_skillset FOREIGN KEY (id_fighter) REFERENCES fighter_character(id_fighter)
	,

	id_skill INT UNIQUE NOT NULL
	CONSTRAINT FK_id_skill_skillset FOREIGN KEY (id_skill) REFERENCES skill(id_skill),

	unlock_lvl INT DEFAULT 0
)

CREATE TABLE mob(
	id_fighter INT UNIQUE NOT NULL
	CONSTRAINT Heritage_id_mob FOREIGN KEY (id_fighter) REFERENCES fighter_character(id_fighter), 
	id_mob INT PRIMARY KEY IDENTITY,
	tier_mob INT,
	xp_drop INT 
)

CREATE TABLE boss(
	id_fighter INT UNIQUE NOT NULL
	CONSTRAINT Heritage_id_boss FOREIGN KEY (id_fighter) REFERENCES fighter_character(id_fighter),
	id_boss INT PRIMARY KEY IDENTITY,
	spawn_condition_boss VARCHAR(50),
	tier_boss INT,
	xp_drop INT 
)

CREATE TABLE archetype(
	id_archetype INT PRIMARY KEY IDENTITY,
	name_archetype VARCHAR(50),
	lvl_scaling VARCHAR(50),
	archetype_description VARCHAR(500)
)

CREATE TABLE player(
	id_fighter INT UNIQUE NOT NULL
	CONSTRAINT Heritage_id_player FOREIGN KEY (id_fighter) REFERENCES fighter_character(id_fighter),

	id_player INT PRIMARY KEY IDENTITY,
	lvl INT,
	xp INT,
	gold INT ,

	archetype_id INT 
	CONSTRAINT FK_archetype_id FOREIGN KEY (archetype_id) REFERENCES archetype(id_archetype) 
)

CREATE TABLE item(
	id_item INT PRIMARY KEY IDENTITY,
	type_item VARCHAR(50),
	effect_item VARCHAR(50),
	effect_value INT,
	description_item VARCHAR(400)
)

CREATE TABLE drop_mob(
	id_mob INT UNIQUE NOT NULL
	CONSTRAINT FK_id_mob FOREIGN KEY (id_mob) REFERENCES mob(id_mob),

	id_item INT UNIQUE NOT NULL
	CONSTRAINT FK_id_item_mob FOREIGN KEY (id_item) REFERENCES item(id_item),

	odd FLOAT ,
	quantity INT
)

CREATE TABLE drop_boss(
	id_boss INT UNIQUE NOT NULL
	CONSTRAINT FK_id_boss FOREIGN KEY (id_boss) REFERENCES boss(id_boss),

	id_item INT UNIQUE NOT NULL
	CONSTRAINT FK_id_item_boss FOREIGN KEY (id_item) REFERENCES item(id_item),

	odd FLOAT ,
	quantity INT
)	

CREATE TABLE iventory_player(
	id_player INT UNIQUE NOT NULL
	CONSTRAINT FK_id_player FOREIGN KEY (id_player) REFERENCES player(id_player),

	id_item INT UNIQUE NOT NULL
	CONSTRAINT FK_id_item_player FOREIGN KEY (id_item) REFERENCES item(id_item),

	quantity INT
)






