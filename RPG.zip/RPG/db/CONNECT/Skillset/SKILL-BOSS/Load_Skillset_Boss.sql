INSERT INTO skill_set(id_fighter,id_skill)
VALUES

-- ARES

(
	(SELECT F.id_fighter
	FROM boss B
	LEFT JOIN fighter_character F ON B.id_fighter = F.id_fighter
	LEFT JOIN game_character G ON F.id_character = G.id_character
	WHERE G.character_name = 'Arès'),

	(SELECT id_skill
	FROM skill
	WHERE name_skill = 'Lance Sangleante')
),

(
	(SELECT F.id_fighter
	FROM boss B
	LEFT JOIN fighter_character F ON B.id_fighter = F.id_fighter
	LEFT JOIN game_character G ON F.id_character = G.id_character
	WHERE G.character_name = 'Arès'),

	(SELECT id_skill
	FROM skill
	WHERE name_skill = 'Massacre Divin')
),

-- ATHENA

(
	(SELECT F.id_fighter
	FROM boss B
	LEFT JOIN fighter_character F ON B.id_fighter = F.id_fighter
	LEFT JOIN game_character G ON F.id_character = G.id_character
	WHERE G.character_name = 'Athéna'),

	(SELECT id_skill
	FROM skill
	WHERE name_skill = 'Frappe Calculée')
),

(
	(SELECT F.id_fighter
	FROM boss B
	LEFT JOIN fighter_character F ON B.id_fighter = F.id_fighter
	LEFT JOIN game_character G ON F.id_character = G.id_character
	WHERE G.character_name = 'Athéna'),

	(SELECT id_skill
	FROM skill
	WHERE name_skill = 'Dernier Jugement')
),

-- PROMETEE

(
	(SELECT F.id_fighter
	FROM boss B
	LEFT JOIN fighter_character F ON B.id_fighter = F.id_fighter
	LEFT JOIN game_character G ON F.id_character = G.id_character
	WHERE G.character_name = 'Prométhée'),

	(SELECT id_skill
	FROM skill
	WHERE name_skill = 'Flamme Volée')
),

(
	(SELECT F.id_fighter
	FROM boss B
	LEFT JOIN fighter_character F ON B.id_fighter = F.id_fighter
	LEFT JOIN game_character G ON F.id_character = G.id_character
	WHERE G.character_name = 'Prométhée'),

	(SELECT id_skill
	FROM skill
	WHERE name_skill = 'Feu Interdit')
),

(
	(SELECT F.id_fighter
	FROM boss B
	LEFT JOIN fighter_character F ON B.id_fighter = F.id_fighter
	LEFT JOIN game_character G ON F.id_character = G.id_character
	WHERE G.character_name = 'Prométhée'),

	(SELECT id_skill
	FROM skill
	WHERE name_skill = 'Chatiment du Titan')
),

-- APOLLON

(
	(SELECT F.id_fighter
	FROM boss B
	LEFT JOIN fighter_character F ON B.id_fighter = F.id_fighter
	LEFT JOIN game_character G ON F.id_character = G.id_character
	WHERE G.character_name = 'Apollon'),

	(SELECT id_skill
	FROM skill
	WHERE name_skill = 'Flèche de Soleil')
),

(
	(SELECT F.id_fighter
	FROM boss B
	LEFT JOIN fighter_character F ON B.id_fighter = F.id_fighter
	LEFT JOIN game_character G ON F.id_character = G.id_character
	WHERE G.character_name = 'Apollon'),

	(SELECT id_skill
	FROM skill
	WHERE name_skill = 'Lumière Vitale')
),

(
	(SELECT F.id_fighter
	FROM boss B
	LEFT JOIN fighter_character F ON B.id_fighter = F.id_fighter
	LEFT JOIN game_character G ON F.id_character = G.id_character
	WHERE G.character_name = 'Apollon'),

	(SELECT id_skill
	FROM skill
	WHERE name_skill = 'Apothéose')
),

-- ATLAS

(
	(SELECT F.id_fighter
	FROM boss B
	LEFT JOIN fighter_character F ON B.id_fighter = F.id_fighter
	LEFT JOIN game_character G ON F.id_character = G.id_character
	WHERE G.character_name = 'Atlas'),

	(SELECT id_skill
	FROM skill
	WHERE name_skill = 'Poing du Titan')
),

(
	(SELECT F.id_fighter
	FROM boss B
	LEFT JOIN fighter_character F ON B.id_fighter = F.id_fighter
	LEFT JOIN game_character G ON F.id_character = G.id_character
	WHERE G.character_name = 'Atlas'),

	(SELECT id_skill
	FROM skill
	WHERE name_skill = 'Pilier du Monde')
),

(
	(SELECT F.id_fighter
	FROM boss B
	LEFT JOIN fighter_character F ON B.id_fighter = F.id_fighter
	LEFT JOIN game_character G ON F.id_character = G.id_character
	WHERE G.character_name = 'Atlas'),

	(SELECT id_skill
	FROM skill
	WHERE name_skill = 'Effondrement Célèste')
),

-- PERSEPHONE

(
	(SELECT F.id_fighter
	FROM boss B
	LEFT JOIN fighter_character F ON B.id_fighter = F.id_fighter
	LEFT JOIN game_character G ON F.id_character = G.id_character
	WHERE G.character_name = 'Perséphone'),

	(SELECT id_skill
	FROM skill
	WHERE name_skill = 'Epine Maudite')
),

(
	(SELECT F.id_fighter
	FROM boss B
	LEFT JOIN fighter_character F ON B.id_fighter = F.id_fighter
	LEFT JOIN game_character G ON F.id_character = G.id_character
	WHERE G.character_name = 'Perséphone'),

	(SELECT id_skill
	FROM skill
	WHERE name_skill = 'Miasme du Tartare')
),

(
	(SELECT F.id_fighter
	FROM boss B
	LEFT JOIN fighter_character F ON B.id_fighter = F.id_fighter
	LEFT JOIN game_character G ON F.id_character = G.id_character
	WHERE G.character_name = 'Perséphone'),

	(SELECT id_skill
	FROM skill
	WHERE name_skill = 'Hiver des Morts')
),

-- HADES

(
	(SELECT F.id_fighter
	FROM boss B
	LEFT JOIN fighter_character F ON B.id_fighter = F.id_fighter
	LEFT JOIN game_character G ON F.id_character = G.id_character
	WHERE G.character_name = 'Hadès'),

	(SELECT id_skill
	FROM skill
	WHERE name_skill = 'Siphon Infernal')
),

(
	(SELECT F.id_fighter
	FROM boss B
	LEFT JOIN fighter_character F ON B.id_fighter = F.id_fighter
	LEFT JOIN game_character G ON F.id_character = G.id_character
	WHERE G.character_name = 'Hadès'),

	(SELECT id_skill
	FROM skill
	WHERE name_skill = 'Drain des Enfers')
),

(
	(SELECT F.id_fighter
	FROM boss B
	LEFT JOIN fighter_character F ON B.id_fighter = F.id_fighter
	LEFT JOIN game_character G ON F.id_character = G.id_character
	WHERE G.character_name = 'Hadès'),

	(SELECT id_skill
	FROM skill
	WHERE name_skill = 'Sentance Mortelle')
),

-- OUROBOROS

(
	(SELECT F.id_fighter
	FROM boss B
	LEFT JOIN fighter_character F ON B.id_fighter = F.id_fighter
	LEFT JOIN game_character G ON F.id_character = G.id_character
	WHERE G.character_name = 'Ouroboros'),

	(SELECT id_skill
	FROM skill
	WHERE name_skill = 'Constrictor')
),

(
	(SELECT F.id_fighter
	FROM boss B
	LEFT JOIN fighter_character F ON B.id_fighter = F.id_fighter
	LEFT JOIN game_character G ON F.id_character = G.id_character
	WHERE G.character_name = 'Ouroboros'),

	(SELECT id_skill
	FROM skill
	WHERE name_skill = 'Cycle Infini')
),

(
	(SELECT F.id_fighter
	FROM boss B
	LEFT JOIN fighter_character F ON B.id_fighter = F.id_fighter
	LEFT JOIN game_character G ON F.id_character = G.id_character
	WHERE G.character_name = 'Ouroboros'),

	(SELECT id_skill
	FROM skill
	WHERE name_skill = 'Dévoration Cosmique')
),

-- CHAOS

(
	(SELECT F.id_fighter
	FROM boss B
	LEFT JOIN fighter_character F ON B.id_fighter = F.id_fighter
	LEFT JOIN game_character G ON F.id_character = G.id_character
	WHERE G.character_name = 'Chaos'),

	(SELECT id_skill FROM skill WHERE name_skill = 'Fragmentation')
),

(
	(SELECT F.id_fighter
	FROM boss B
	LEFT JOIN fighter_character F ON B.id_fighter = F.id_fighter
	LEFT JOIN game_character G ON F.id_character = G.id_character
	WHERE G.character_name = 'Chaos'),

	(SELECT id_skill FROM skill WHERE name_skill = 'Incandescence')
),

(
	(SELECT F.id_fighter
	FROM boss B
	LEFT JOIN fighter_character F ON B.id_fighter = F.id_fighter
	LEFT JOIN game_character G ON F.id_character = G.id_character
	WHERE G.character_name = 'Chaos'),

	(SELECT id_skill FROM skill WHERE name_skill = 'Genesis')
),

(
	(SELECT F.id_fighter
	FROM boss B
	LEFT JOIN fighter_character F ON B.id_fighter = F.id_fighter
	LEFT JOIN game_character G ON F.id_character = G.id_character
	WHERE G.character_name = 'Chaos'),

	(SELECT id_skill FROM skill WHERE name_skill = 'Paradoxe')
),

(
	(SELECT F.id_fighter
	FROM boss B
	LEFT JOIN fighter_character F ON B.id_fighter = F.id_fighter
	LEFT JOIN game_character G ON F.id_character = G.id_character
	WHERE G.character_name = 'Chaos'),

	(SELECT id_skill FROM skill WHERE name_skill = 'Décomposition')
),

(
	(SELECT F.id_fighter
	FROM boss B
	LEFT JOIN fighter_character F ON B.id_fighter = F.id_fighter
	LEFT JOIN game_character G ON F.id_character = G.id_character
	WHERE G.character_name = 'Chaos'),

	(SELECT id_skill FROM skill WHERE name_skill = 'Assimilation')
),

(
	(SELECT F.id_fighter
	FROM boss B
	LEFT JOIN fighter_character F ON B.id_fighter = F.id_fighter
	LEFT JOIN game_character G ON F.id_character = G.id_character
	WHERE G.character_name = 'Chaos'),

	(SELECT id_skill FROM skill WHERE name_skill = 'Noir Absolu')
),

(
	(SELECT F.id_fighter
	FROM boss B
	LEFT JOIN fighter_character F ON B.id_fighter = F.id_fighter
	LEFT JOIN game_character G ON F.id_character = G.id_character
	WHERE G.character_name = 'Chaos'),

	(SELECT id_skill FROM skill WHERE name_skill = 'Instabilité')
),

(
	(SELECT F.id_fighter
	FROM boss B
	LEFT JOIN fighter_character F ON B.id_fighter = F.id_fighter
	LEFT JOIN game_character G ON F.id_character = G.id_character
	WHERE G.character_name = 'Chaos'),

	(SELECT id_skill FROM skill WHERE name_skill = 'Apocalypse')
);

