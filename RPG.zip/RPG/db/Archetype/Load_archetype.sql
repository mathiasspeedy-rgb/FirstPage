INSERT INTO archetype (name_archetype,archetype_description)
VALUES 
	(
	'Hercule',
	'Le héro des 12 travaux, incarnation de la force brute.Chaque coup semble capable de briser le monde'
	),

	
	(
	'Ulysse',
	'Un stratège légendaire, maitre de la ruse et des plans impossibles.Il ne gagne pas par la force... mais en faisant tomber ses ennemis dans leurs propes pieges'
	),
	
	
	(
	'Ramsès',
	'Maître des tempêtes et du chaos du désert. Sous ses sables maudits, la vue se troubke et la certitude disparait'
	
	),
	(
	'Ulysse',
	'Un stratège légendaire, maitre de la ruse et des plans impossibles. Il ne gagne pas par la force... mais en faisant tomber ses ennemis dans leurs propes pieges'
	),

	(
	'Ragnar',
	'Un guerrier viking emporté par la rage de combat. Quand il entre en transe, il ne distingue plus ses enemis de la mort elle même'
	),

	(
	'Icare',
	'Un homme a défié les soleil lui même et en a payé le prix. Dotés de la même intelligence que son père Dédale sa puissance brule tout... même lui'
	),

	(
	'Médée',
	'Une maitresse des poisons et des remèdes oubliés, celle qui condamne Jason par sa veangeance. Sa science transforme la vie en lente agonie, ses toxines affaiblissent ses ennemis de plus en plus..'
	),

	(
	'Pythie',
	'La voix es Dieux à travers une prêtresse sacrée. Elle canalise la volonté divine par le soin et la protection. Ses paroles jugent autant que elles maintiennent en vie'
	),

	(
	'Léonidas',
	'Le défenseur de Sparte, roi qui ne recule jamais. Il se défend jusque son dernier souffle, lorsque son armee meurt lui se bat encore'
	),
	
	(
	'Dracula',
	'Maudit depuis une éternité, il survit en volant la vie de ses ennemis. Chaque combat est une faim que personne ne pourra jamais apaiser'
	)