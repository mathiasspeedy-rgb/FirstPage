SELECT A.id_archetype,A.name_archetype,A.archetype_description
FROM archetype A
