# Solo RPG - Python Project

A fully-featured solo RPG game built in Python with a modular, factory-based architecture. The game features procedural enemy generation, dynamic combat systems, progression mechanics, and an interactive UI layer.

## Overview

This is a structured turn-based RPG where players progress through multiple chapters (tiers), battling increasingly difficult enemies and bosses. The game includes:

- **Player progression** with leveling, stat scaling, and archetype-based skill selection
- **Procedural mob generation** with tier-based difficulty and shadow variants
- **Dynamic combat system** with skill bricks, status effects, and special abilities
- **Interactive UI** with chapter selection, enemy indexing, and combat feedback
- **Boss encounters** with unique mechanics and multi-phase combat
- **Archetype system** allowing players to switch between character classes (Fighter, Mage, Rogue, Tank, Healer, and more)

## Project Structure

```
project/
├── factories/
│   ├── mob_factory.py          # Generates procedural mobs and bosses
│   ├── boss_factory.py         # Creates unique boss encounters
│   ├── archetype_factory.py    # Defines player archetypes and skill sets
│   ├── skill_factory.py        # Constructs skills from composable bricks
│   └── tier_factory.py         # Manages tier-based progression and scaling
├── entities/
│   ├── fighter.py              # Base entity class (mobs, bosses, player)
│   ├── player.py               # Player-specific logic and progression
│   └── skill.py                # Skill definition with brick composition
├── core/
│   ├── engine.py               # Core game loop and turn management
│   ├── progression.py          # Player progression state and tracking
│   └── combat.py               # Combat resolution and mechanics
├── ui/
│   └── display.py              # Text-based UI and player interaction
├── data/
│   ├── mob.txt                 # Enemy and skill name data
│   └── tasks.txt               # Development task tracking
└── main.py                     # Game entry point
```

## Core Systems

### 1. Factory Pattern Architecture

The project uses factories to generate and manage game entities:

- **MobFactory**: Generates mobs based on tier, with configurable stats, skills, and names
- **BossFactory**: Creates unique boss encounters with special mechanics and multi-phase health pools
- **ArchetypeFactory**: Defines player character classes with unique skill sets and stat distributions
- **SkillFactory**: Constructs skills by composing modular "bricks" (damage, healing, status effects, etc.)
- **TierFactory**: Manages chapter progression, defines difficulty scaling, and populates enemy pools

### 2. Skill Brick System

Skills are built from composable bricks that define specific effects:

- **`dmg`**: Direct damage based on attacker's `power` and defender's `defense`
- **`heal`**: Restore health to target or self
- **`crit`**: Apply critical hit modifier based on `intelligence` stat
- **`apply_status`**: Apply status effects (burn, poison, etc.) with scaling
- **`lifesteal`**: Combine damage and healing effects
- **`debuff`**: Reduce enemy stats (planned feature)

Skills are keyed by proper names (e.g., `"Fiole Toxique"`, `"Éclair Divin"`) and include auto-generated descriptions based on their brick composition.

### 3. Entity Hierarchy

```
Fighter (base entity)
├── Stats: power, intelligence, defense, health (pv)
├── Skills: equipped active skills
└── Status: active effects (burn, poison, etc.)

Player (extends Fighter)
├── Experience & Leveling
├── Archetype selection
├── Tier progression
└── Kill tracking & statistics

Mob (extends Fighter)
├── Procedurally generated names
├── Tier-based difficulty scaling
└── Shadow variants (60% health, 70% power for completed tiers)

Boss (extends Fighter)
├── Unique multi-phase encounters
├── Special mechanics per boss
└── Higher stat scaling
```

### 4. Progression System

**GameProgression** tracks:
- Current tier (chapter) and viewing tier (for chapter revisits)
- Player level and experience
- Killed enemies and completed tiers
- Archetype history and stat evolution
- Shadow boss spawning logic

**Features:**
- Non-linear chapter revisiting with shadow mob variants
- Kill increments gated to `viewing_tier == current_tier`
- Full tier history with descriptions for killed enemies and names-only for unseen enemies

### 5. Combat Mechanics

Combat is turn-based with the following flow:

1. Player selects an action (skill or defend)
2. Skill is resolved applying all bricks in sequence
3. Defender receives damage, heals, or status effects
4. Defender counter-attacks
5. End-of-turn status effects are applied (poison damage increases per turn)
6. Combat ends when either combatant reaches 0 health

**Key Stats:**
- **Power**: Increases outgoing damage (formerly `base_dmg`)
- **Intelligence**: Increases critical hit chance (formerly `crit_rate`)
- **Defense**: Reduces incoming damage
- **PV (Health)**: Current health points; PVMax is maximum health

### 6. Status Effects

- **Burn (`brûlure`)**: Deals fixed damage per turn
- **Poison (`psn`)**: Damage scales up each turn; distinct from burn
- **Apply Status**: Three-parameter system (`status`, `lancer`, `cible`) for flexible effect application

## Recent Updates

### Skill Naming Refactor
Skill dictionaries now use proper skill names as keys rather than generic role identifiers:
```python
# Before
skills = {"attack": Skill(...), "ult": Skill(...)}

# After
skills = {"Fiole Toxique": Skill(...), "Éclair Divin": Skill(...)}
```

### Stat Renames
- `base_dmg` → `power`
- `base_crit` / `crit_rate` → `intelligence`
- `base_def` → `defense` (new stat for all entities)

### Tier Revisiting & Shadow Mobs
Players can revisit completed tiers and encounter weaker "shadow" versions of enemies (60% health, 70% power) to grind or replay.

### Archetype Expansion
- **Icare, Médée, Dracula** added to the archetype roster
- Médée uses poison status with scaling damage
- Dracula combines lifesteal mechanics

## Known Issues & Planned Features

### Deferred
- Fix `build_all()` and combat UI logic broken by skill naming refactor
- Implement dedicated `Status` class (currently using `None` placeholders for `lancer` and `cible`)
- Mechanically implement `debuff` brick type

### Data Validation
- Name normalization edge cases (Cerbère, Hypolite, Échec 0) handled with manual fallbacks
- Archetype `pvmax` values adjusted for consistent tier scaling

## Getting Started

### Requirements
- Python 3.8+

### Installation
```bash
unzip project.zip
cd project
python main.py
```

### Gameplay
1. Start a new game and select an archetype
2. Progress through tiers (chapters) by defeating enemies
3. Gain experience, level up, and unlock new skills
4. Revisit completed tiers to challenge shadow variants
5. Advance to harder tiers and face unique bosses

## Development Workflow

Tasks are tracked in `tasks.txt` with each session completing specific, scoped objectives. Changes are validated via:
- Syntax verification with `ast.parse` across the full codebase
- Smoke testing of core systems (mob generation, combat, progression)
- Zip packaging for iterative development

## Architecture Principles

1. **Modularity**: Factories encapsulate entity generation; bricks compose skills
2. **Scalability**: Tier-based difficulty allows easy adjustment of enemy power curves
3. **Extensibility**: New archetypes, bosses, and status effects can be added without refactoring core systems
4. **Data-Driven**: Enemy stats and names are sourced from `mob.txt`, allowing quick iteration
5. **Edge Case Handling**: Manual fallbacks for name normalization prevent crashes on malformed data

## Future Roadmap

- [ ] Dedicated Status class with proper `lancer` and `cible` tracking
- [ ] Debuff mechanic implementation
- [ ] Combat UI polish (break into separate module)
- [ ] Enemy equipment/loot system
- [ ] Skill unlock progression tree
- [ ] PvP encounter system
- [ ] Save/load game state
- [ ] Configuration file for difficulty scaling
- [ ] Localization support (French/English toggle)

## License

Solo project, personal use.

---

**Last Updated**: September 2026  
**Status**: Active Development