USE staging

CREATE TABLE [etnicity] (
    [Race] nvarchar(255),
    [State] nvarchar(255),
    [Population] float,
    [Total population] float
)

CREATE TABLE [city] (
    [Column 0] varchar(50),
    [city] varchar(50),
    [city_ascii] varchar(50),
    [state_id] varchar(50),
    [state_name] varchar(50),
    [county_fips] varchar(50),
    [county_name] varchar(50),
    [county_fips_all] varchar(50),
    [county_name_all] varchar(50),
    [lat] varchar(50),
    [lng] varchar(50),
    [population] varchar(50),
    [density] varchar(50),
    [source] varchar(50),
    [military] varchar(50),
    [incorporated] varchar(50),
    [timezone] varchar(50),
    [ranking] varchar(50),
    [id] varchar(50)
)

CREATE TABLE [shoot] (
    [id] varchar(50),
    [name] varchar(50),
    [date] varchar(50),
    [manner_of_death] varchar(50),
    [armed] varchar(50),
    [age] varchar(50),
    [gender] varchar(50),
    [race] varchar(50),
    [city] varchar(50),
    [state] varchar(50),
    [signs_of_mental_illness] varchar(50),
    [threat_level] varchar(50),
    [flee] varchar(50),
    [body_camera] varchar(50),
    [longitude] varchar(50),
    [latitude] varchar(50),
    [is_geocoding_exact] varchar(50)
)

CREATE TABLE Dim_Date(
    Date_Id INT,
    [Date] Date,
    [Day] INT,
    [Month] INT,
    [Year] INT
)

CREATE TABLE [fuzzy_city](
    [city] varchar(50),
    [state] varchar(50),
    [city_ascii] varchar(50),
    [state_id] varchar(50),
    [_Similarity] real,
    [_Confidence] real,
    [_Similarity_city] real
)