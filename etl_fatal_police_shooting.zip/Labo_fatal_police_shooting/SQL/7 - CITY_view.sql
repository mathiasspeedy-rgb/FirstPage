CREATE OR ALTER VIEW city.AllFromCity
AS

SELECT 
	C.city AS City,
	C.city_ascii AS City_Ascii,
	C.state_id AS State_Id,
	C.state_name AS State_Name,
	C.county_fips AS County_Fips,
	C.county_name AS County_Name,
	C.county_fips_all County_Fips_All,
	C.county_name_all AS County_Name_All,
	CAST(C.population AS FLOAT) AS City_Population,
	CAST(C.density AS FLOAT) AS City_Density,
	dbo.VarcharToBit(C.military) AS Military,
	dbo.VarcharToBit(C.incorporated) AS Incorporated,
	C.timezone AS Timezone,
	CAST(C.ranking AS INT) AS Ranking,
	CAST(C.lng AS FLOAT) AS Longitude,
	CAST(C.lat AS FLOAT) AS Latitude

FROM city C

GO
CREATE OR ALTER VIEW city.City_Matched_Like
AS

SELECT 
	C.city AS City,
	C.city_ascii AS City_Ascii,
	C.state_id AS State_Id,
	C.state_name AS State_Name,
	C.county_fips AS County_Fips,
	C.county_name AS County_Name,
	C.county_fips_all County_Fips_All,
	C.county_name_all AS County_Name_All,
	CAST(C.population AS FLOAT) AS City_Population,
	CAST(C.density AS FLOAT) AS City_Density,
	dbo.VarcharToBit(C.military) AS Military,
	dbo.VarcharToBit(C.incorporated) AS Incorporated,
	C.timezone AS Timezone,
	CAST(C.ranking AS INT) AS Ranking,
	CAST(C.lng AS FLOAT) AS Longitude,
	CAST(C.lat AS FLOAT) AS Latitude

FROM city C JOIN city.MatchedCity_Like CML ON C.city_ascii = CML.matched_city AND CML.state = C.state_id

GO
CREATE OR ALTER VIEW city.City_Matched_Fuzzy
AS

SELECT 
	C.city AS City,
	C.city_ascii AS City_Ascii,
	C.state_id AS State_Id,
	C.state_name AS State_Name,
	C.county_fips AS County_Fips,
	C.county_name AS County_Name,
	C.county_fips_all County_Fips_All,
	C.county_name_all AS County_Name_All,
	CAST(C.population AS FLOAT) AS City_Population,
	CAST(C.density AS FLOAT) AS City_Density,
	dbo.VarcharToBit(C.military) AS Military,
	dbo.VarcharToBit(C.incorporated) AS Incorporated,
	C.timezone AS Timezone,
	CAST(C.ranking AS INT) AS Ranking,
	CAST(C.lng AS FLOAT) AS Longitude,
	CAST(C.lat AS FLOAT) AS Latitude

FROM fuzzy_city F LEFT JOIN city C ON (F.city_ascii = C.city_ascii)
WHERE F._Similarity >0.775

GO
CREATE OR ALTER VIEW city.UnMatched_Fuzzy
AS

SELECT DISTINCT
	F.city AS City,
	CAST(NULL AS VARCHAR(50)) AS City_Ascii,
	F.state_id AS State_Id,
	C.state_name AS State_Name,
	CAST(NULL AS VARCHAR(50)) AS County_Fips,
	CAST(NULL AS VARCHAR(50)) AS County_Name,
	CAST(NULL AS VARCHAR(50)) County_Fips_All,
	CAST(NULL AS VARCHAR(50)) AS County_Name_All,
	CAST(NULL AS VARCHAR(50)) AS City_Population,
	CAST(NULL AS VARCHAR(50)) AS City_Density,
	CAST(NULL AS VARCHAR(50)) AS Military,
	CAST(NULL AS VARCHAR(50)) AS Incorporated,
	CAST(NULL AS VARCHAR(50)) AS Timezone,
	CAST(NULL AS VARCHAR(50)) AS Ranking,
	CAST(NULL AS VARCHAR(50)) AS Longitude,
	CAST(NULL AS VARCHAR(50)) AS Latitude
FROM fuzzy_city F LEFT JOIN city C ON F.state_id = C.state_id
WHERE F._Similarity <=0.775



