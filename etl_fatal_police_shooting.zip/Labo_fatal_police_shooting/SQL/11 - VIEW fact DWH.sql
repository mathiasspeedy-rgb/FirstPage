USE staging
GO
CREATE OR ALTER VIEW etl.Fact_Etnicity
AS

SELECT 
	S.State_Code,
	R.Race_Id,
	E.Population

FROM etnicity E LEFT JOIN etl.Dim_State S ON E.State = S.State_Name
LEFT JOIN etl.Dim_Race R ON E.Race = R.Race_Name

GO
CREATE OR ALTER VIEW etl.Fact_Fatal_Police_Shoot_Murder
AS

SELECT
	C.Context_Id AS Context_Id,
	D.date_id AS Date_Id,
	V.Victim_Id AS Victim_Id,
	L.City_Id AS City_Id,
	S.latitude,
	S.longitude,
	dbo.VarcharToBit(is_geocoding_exact) AS Is_Geocoding_Exact

FROM shoot S 
LEFT JOIN DWH_Laboratoire.dbo.Dim_Context C ON 
S.armed = C.Armed AND
S.flee = C.Flee AND
S.threat_level = C.Threat_Level AND
S.manner_of_death = C.Manner_of_Death AND
S.body_camera = C.body_camera

LEFT JOIN etl.Dim_Date D ON
S.date = D.date

LEFT JOIN DWH_Laboratoire.dbo.Dim_Victim V ON 
S.name = V.Name AND
S.age = V.Age AND
S.gender = V.Gender AND
COALESCE(NULLIF(S.race, ''), 'U') = V.Race_Code AND 
dbo.VarcharToBit(signs_of_mental_illness) = V.Signs_Of_Mental_Ilness

LEFT JOIN DWH_Laboratoire.dbo.Dim_Localisation L ON
S.city = L.City
AND S.state = L.State_Id


