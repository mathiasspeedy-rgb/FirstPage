DROP TABLE IF EXISTS city.UnMatchedCity;
GO

CREATE TABLE city.UnMatchedCity
(
    city  NVARCHAR(255),
    state NVARCHAR(10)
);
GO

INSERT INTO city.UnMatchedCity (city, state)
SELECT DISTINCT
    S.city,
    S.state
FROM shoot S
WHERE S.city IS NOT NULL
  AND NOT EXISTS
  (
      SELECT 1
      FROM city C
      WHERE C.state_id = S.state
        AND C.city_ascii = S.city
  );
GO

DROP TABLE IF EXISTS city.MatchedCity_Like;
GO

CREATE TABLE city.MatchedCity_Like
(
    shoot_city   NVARCHAR(255),
    state        NVARCHAR(10),
    matched_city NVARCHAR(255)
);
GO

INSERT INTO city.MatchedCity_Like
(
    shoot_city,
    state,
    matched_city
)
SELECT DISTINCT
    U.city AS shoot_city,
    U.state,
    C.city_ascii AS matched_city
FROM city.UnMatchedCity U
INNER JOIN city C
    ON C.state_id = U.state
   AND (
       C.city_ascii LIKE '%' + U.city + '%'
       OR
       U.city LIKE '%' + C.city_ascii + '%'
   );
GO

DROP TABLE IF EXISTS city.UnMatchedCity_Like;
GO

CREATE TABLE city.UnMatchedCity_Like
(
    city  VARCHAR(50),
    state VARCHAR(50)
);
GO

INSERT INTO city.UnMatchedCity_Like
(
    city,
    state
)
SELECT DISTINCT
    U.city,
    U.state
FROM city.UnMatchedCity U
WHERE NOT EXISTS
(
    SELECT 1
    FROM city C
    WHERE C.state_id = U.state
      AND (
          C.city_ascii LIKE '%' + U.city + '%'
          OR
          U.city LIKE '%' + C.city_ascii + '%'
      )
);
