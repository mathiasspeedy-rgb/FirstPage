USE DWH_Laboratoire
DROP TABLE[dbo].[Dim_Context]

CREATE TABLE [dbo].[Dim_Context](
	[Context_Id] [int] IDENTITY,
	[Threat_Level] [varchar](50) NULL,
	[Flee] [varchar](50) NULL,
	[Manner_of_Death] [varchar](50) NULL,
	[Armed] [varchar](50) NULL,
	[body_camera] BIT,

	CONSTRAINT [PK_Dim_Context] PRIMARY KEY ([Context_Id])
 )

CREATE TABLE [dbo].[Dim_Date](
	[date_id] [int] NOT NULL,
	[date] [date] NULL,
	[day] [int] NULL,
	[month] [int] NULL,
	[year] [int] NULL,

	CONSTRAINT [PK_Dim_Date] PRIMARY KEY ([date_id] )
 )

CREATE TABLE [dbo].[Dim_Race](
	[Race_Id] [varchar](50) NOT NULL,
	[Race_Name] [varchar](15) NULL,

	CONSTRAINT [PK_Dim_Race] PRIMARY KEY ([Race_Id] )
)

CREATE TABLE [dbo].[Dim_State](
	[State_Code] [varchar](50) NOT NULL,
	[State_Name] [varchar](50) NULL,
	[State_Population] [float] NULL,[armed]

	CONSTRAINT [PK_Dim_State] PRIMARY KEY([State_Code])
)


CREATE TABLE [dbo].[Dim_Victim](
	[Victim_Id] [int] IDENTITY NOT NULL,
	[Name] [varchar](50) NULL,
	[Age] [int] NULL,
	[Gender] [varchar](50) NULL,
	[Race_Code] [varchar](50) NULL,
	[Signs_Of_Mental_Ilness] [bit] NULL,

	CONSTRAINT [PK_Dim_Victim] PRIMARY KEY ([Victim_Id] ),
	CONSTRAINT [FKRace_Code] FOREIGN KEY([Race_Code]) REFERENCES [dbo].[Dim_Race] ([Race_Id])
)

CREATE TABLE [dbo].[Dim_Localisation](
	[City_Id] [int] IDENTITY NOT NULL,
	[City] [varchar](50) NULL,
	[City_Ascii] [varchar](50) NULL,
	[State_Id] [varchar](50) NULL,
	[County_Fips] [varchar](50) NULL,
	[County_Name] [varchar](50) NULL,
	[County_Fips_All] [varchar](50) NULL,
	[County_Name_All] [varchar](50) NULL,
	[City_Population] [float] NULL,
	[City_Density] [float] NULL,
	[Military] [bit] NULL,
	[Incorporated] [bit] NULL,
	[Timezone] [varchar](50) NULL,
	[Ranking] [int] NULL,
	[Longitude] [float] NULL,
	[Latitude] [float] NULL,

	CONSTRAINT [PK_Dim_Localisation] PRIMARY KEY ([City_Id] ),
	CONSTRAINT [FKRace_State_Id] FOREIGN KEY([State_Id]) REFERENCES [dbo].[Dim_State] ([State_Code])
)


CREATE TABLE Fact_State_Etnicity_Population(
	State_Etnicity_Id INT IDENTITY,
    [State_Code] varchar(50),
    [Race_Id] varchar(50),
    [Population] float,

	CONSTRAINT PK_State_Etnicity_Population PRIMARY KEY (State_Etnicity_Id ),
	CONSTRAINT FKRace_State_Code FOREIGN KEY([State_Code]) REFERENCES [dbo].[Dim_State] ([State_Code]),
	CONSTRAINT FKRace_Code_Etnicity_Population FOREIGN KEY([Race_Id]) REFERENCES [dbo].[Dim_Race] ([Race_Id])
)

CREATE TABLE Fact_Fatal_Police_Shooting (
	Fatal_Police_Shooting_Id INT IDENTITY,
    [Context_Id] int,
    [Date_Id] int,
    [Victim_Id] int,
    [City_Id] int,
    [latitude] varchar(50),
    [longitude] varchar(50),
    [Is_Geocoding_Exact] bit,

	CONSTRAINT PK_Fatal_Police_Shooting PRIMARY KEY (Fatal_Police_Shooting_Id ),
	CONSTRAINT FK_Fatal_Police_Shooting__Context_Id FOREIGN KEY([Context_Id]) REFERENCES [dbo].[Dim_Context] ([Context_Id]),
	CONSTRAINT FK_PK_Fatal_Police_Shooting__Date_Id FOREIGN KEY([Date_Id]) REFERENCES [dbo].[Dim_Date] ([date_Id]),
	CONSTRAINT FK_PK_Fatal_Police_Shooting__Victim_Id FOREIGN KEY([Victim_Id]) REFERENCES [dbo].[Dim_Victim] ([Victim_Id]),
	CONSTRAINT FK_PK_Fatal_Police_Shooting__City_Id FOREIGN KEY([City_Id]) REFERENCES [dbo].[Dim_Localisation] ([City_Id])
)




