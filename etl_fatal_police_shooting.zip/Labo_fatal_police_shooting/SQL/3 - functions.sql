CREATE FUNCTION dbo.VarcharToBit (@value VARCHAR(10))
RETURNS BIT
AS
BEGIN
    DECLARE @result BIT;

    SET @result =
        CASE
            WHEN LOWER(TRIM(@value)) = 'true' THEN 1
            WHEN LOWER(TRIM(@value)) = 'false' THEN 0
            ELSE NULL
        END;

    RETURN @result;
END;
GO

CREATE OR ALTER PROCEDURE dbo.Generate_DimDate
    @DateDebut DATE,
    @DateFin DATE
AS
BEGIN
    SET NOCOUNT ON;

    -- Créer la table si elle n'existe pas encore
    IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'TableDate' AND schema_id = SCHEMA_ID('dbo'))
    BEGIN
        CREATE TABLE dbo.TableDate
        (
            date_id INT PRIMARY KEY,
            [date]  DATE,
            [day]   INT,
            [month] INT,
            [year]  INT
        );
    END;

    DECLARE @DateCourante DATE = @DateDebut;

    WHILE @DateCourante <= @DateFin
    BEGIN
        IF NOT EXISTS (
            SELECT 1
            FROM dbo.TableDate
            WHERE [date] = @DateCourante
        )
        BEGIN
            INSERT INTO dbo.TableDate
            (
                date_id,
                [date],
                [day],
                [month],
                [year]
            )
            VALUES
            (
                CONVERT(INT, CONVERT(CHAR(8), @DateCourante, 112)),
                @DateCourante,
                DAY(@DateCourante),
                MONTH(@DateCourante),
                YEAR(@DateCourante)
            );
        END;

        SET @DateCourante = DATEADD(DAY, 1, @DateCourante);
    END;
END;
GO

DECLARE @debut DATE;
DECLARE @fin DATE;

SELECT
    @debut = MIN(CAST(S.[date] AS DATE)),
    @fin = MAX(CAST(S.[date] AS DATE))
FROM shoot S;

EXEC dbo.Generate_DimDate @debut, @fin;