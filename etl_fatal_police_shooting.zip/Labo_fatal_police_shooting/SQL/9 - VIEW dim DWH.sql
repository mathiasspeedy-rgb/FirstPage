USE staging
GO

CREATE OR ALTER VIEW etl.Dim_Localisation
AS 

SELECT 
	*


FROM city.AllFromCity

UNION

SELECT 
	*
FROM city.City_Matched_Like
UNION

SELECT 
	*
FROM city.City_Matched_Fuzzy
UNION

SELECT *
FROM city.UnMatched_Fuzzy

GO 
CREATE OR ALTER VIEW etl.Dim_Context
AS

SELECT
	S.threat_level AS Threat_Level,
	S.flee AS Flee,
	S.manner_of_death AS Manner_of_Death,
	S.armed AS Armed
FROM shoot S


GO
CREATE OR ALTER VIEW etl.Dim_Victim
AS

SELECT DISTINCT
	S.name AS Name,
	CAST(S.age AS INT) AS Age,
	S.gender AS Gender,
	COALESCE(NULLIF(S.race,''), 'U') AS Race_Code,
	dbo.VarcharToBit(S.signs_of_mental_illness) AS Signs_Of_Mental_Ilness

FROM shoot S

GO
CREATE OR ALTER VIEW etl.Dim_Race
AS

SELECT DISTINCT
	COALESCE(NULLIF(S.race,''), 'U') AS Race_Id,
	CASE 
        WHEN S.race = 'W' THEN 'White'
		WHEN S.race = 'B' THEN 'Black'
		WHEN S.race = 'H' THEN 'Hispanic'
		WHEN S.race = 'A' THEN 'Asian'
		WHEN S.race = 'N' THEN 'American Indian'
		WHEN S.race = 'O' THEN 'Other'
		ELSE 'Undefined'
	END AS Race_Name
FROM shoot S

GO
CREATE OR ALTER VIEW etl.Dim_State
AS
SELECT DISTINCT
	C.state_id AS State_Code,
	C.state_name AS State_Name,
	CAST(E.[Total population] AS FLOAT) AS State_Population
FROM city C LEFT JOIN etnicity E ON C.state_name = E.State


DECLARE @debut DATE;
DECLARE @fin DATE;

SELECT
    @debut = MIN(CAST(S.date AS DATE)),
    @fin   = MAX(CAST(S.date AS DATE))
FROM shoot S

EXEC dbo.Generate_DimDate @DateDebut = @debut, @DateFin = @fin;
	
GO 
CREATE OR ALTER VIEW etl.Dim_Date 
AS

SELECT * 
FROM TableDate






