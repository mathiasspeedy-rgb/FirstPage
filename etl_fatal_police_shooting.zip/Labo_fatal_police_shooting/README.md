# Fatal Police Shooting Analytics - ETL Data Warehouse Project

An advanced ETL (Extract-Transform-Load) project analyzing fatal police shootings in the United States. This project integrates multiple data sources (shootings, geographic, and demographic data) into a structured dimensional data warehouse using SSIS and SQL Server, enabling comprehensive analytics and insights.

## 📋 Project Overview

This laboratory project demonstrates enterprise-level data integration and warehousing techniques applied to a sensitive social dataset. The goal is to provide researchers, policymakers, and analysts with clean, enriched data for exploring patterns in fatal police encounters across the US.

**Key Objectives:**
- Integrate three disparate data sources (shootings, cities, ethnicity/population)
- Create a robust ETL pipeline using SSIS (SQL Server Integration Services)
- Build a dimensional data warehouse for multi-dimensional analysis
- Implement data quality measures (fuzzy matching, lookups, deduplication)
- Enable analysis across geographic, temporal, and demographic dimensions

**Dataset Scope:** Fatal police shooting incidents in the United States with context on victim demographics, incident circumstances, and location data.

## 🏗️ Project Architecture

```
Labo_fatal_police_shooting/
├── Datas/                              # Source data files
│   ├── fatal-police-shootings.csv      # Main incident data (808 KB)
│   ├── uscities_v2.csv                 # US cities geographic/demographic data (4.1 MB)
│   ├── Ethnicity Data USA.xlsx         # Population by ethnicity and state
│   └── about_datas.txt                 # Data source documentation
│
├── SQL/                                # T-SQL scripts (execution order matters!)
│   ├── 1 - CREATE TABLE staging.sql        # Create staging schema
│   ├── 3 - functions.sql                   # Helper functions
│   ├── 4 - CREATE SCHEMA.sql               # Create DWH schema
│   ├── 5 - CITY.sql                        # Load city dimension
│   ├── 7 - CITY_view.sql                   # Create city views
│   ├── 8 - CREATE TABLE DWH_Laboratoire.sql # Create DWH tables
│   ├── 9 - VIEW dim DWH.sql                # Create dimension views
│   └── 11 - VIEW fact DWH.sql              # Create fact table views
│
├── Visual_Studio/                      # SSIS ETL Packages
│   ├── Extract_Load_Staging_Data.dtsx  # Extract raw data into staging (step 1)
│   ├── Fuzzy.dtsx                      # Fuzzy matching & data cleansing (step 2)
│   ├── Load_Dim.dtsx                   # Load cleaned dimensions (step 3)
│   ├── Load_Fact.dtsx                  # Load transformed facts (step 4)
│   ├── Labo.dtproj                     # SSIS project file
│   └── Project.params                  # Configuration parameters
│
├── DWH_Model.loo                       # Logical data model diagram (Lucidchart)
├── Execution_Process.txt               # Step-by-step execution guide
└── README.txt                          # Original documentation (see this improved README)
```

## 📊 Data Sources

### Source 1: Fatal Police Shootings Dataset
**File:** `fatal-police-shootings.csv` (main incident data)

**Records:** ~1,000+ incidents  
**Time Period:** Historical data through submission date  
**Key Fields:**
- `id`, `name` - Victim identifier
- `date` - Incident date (YYYY-MM-DD format)
- `manner_of_death` - Method (shot, taser, etc.)
- `armed` - Victim weapon/item (gun, knife, unarmed, etc.)
- `age`, `gender`, `race` - Victim demographics
- `city`, `state` - Incident location
- `signs_of_mental_illness` - Boolean flag
- `threat_level` - Perceived threat (attack, other, undetermined)
- `flee` - Whether victim fled (car, foot, not fleeing, etc.)
- `body_camera` - Body camera present (True/False/Not specified)
- `longitude`, `latitude` - GPS coordinates
- `is_geocoding_exact` - Geocoding accuracy flag

### Source 2: US Cities Geographic Dataset
**File:** `uscities_v2.csv`

**Records:** ~28,000+ US cities and localities  
**Key Fields:**
- `city`, `city_ascii` - City name variations
- `state_id`, `state_name` - State information
- `lat`, `lng` - Latitude, longitude
- `population` - City population estimate
- `density` - Population density (people per sq km)
- `county_fips`, `county_name` - County identifiers
- `timezone` - Time zone
- `id` - Unique city identifier

### Source 3: US Population by Ethnicity & State
**File:** `Ethnicity Data USA.xlsx`

**Records:** Population statistics by state and ethnic/racial category  
**Key Fields:**
- `Race` - Racial/ethnic category
- `State` - US state
- `Population` - Count in this group for this state
- `Total population` - Total state population

## 🔄 ETL Workflow

### Phase 1: Data Extraction & Staging
**Script:** `1 - CREATE TABLE staging.sql`  
**SSIS Package:** `Extract_Load_Staging_Data.dtsx`

**Actions:**
- Create staging database and raw data tables
- Load flat files directly into staging tables with minimal transformation
- Preserve all source data integrity (no cleansing at this stage)
- Tables created: `[shoot]`, `[city]`, `[etnicity]`

**Input:** CSV/XLSX files  
**Output:** Staging tables with source data

---

### Phase 2: Helper Functions & Setup
**Scripts:** `3 - functions.sql`, `4 - CREATE SCHEMA.sql`, `5 - CITY.sql`

**Actions:**
- Create utility functions for data transformation
- Create DWH schema and organizational structure
- Pre-load city dimension with clean reference data
- Scripts numbered sequentially for controlled execution

**Input:** Staging tables  
**Output:** DWH schema ready for transformation

---

### Phase 3: Data Cleansing (Fuzzy Matching)
**SSIS Package:** `Fuzzy.dtsx`

**Actions:**
- Implement **Fuzzy Matching** on city/state combinations to resolve name variations
- Handle typos and alternate spellings in location data
- Prevent duplicate records using Lookup transformations
- Score and rank potential matches
- Create cleansed intermediate tables

**Techniques:**
- Token-based matching on city names
- Edit distance similarity scoring
- Confidence threshold filtering (typically 0.8+)
- Manual review of low-confidence matches

**Input:** Staging data  
**Output:** Cleansed intermediate tables with match confidence scores

---

### Phase 4: Dimension & Fact Table Loading
**Scripts:** `7 - CITY_view.sql`, `8 - CREATE TABLE DWH_Laboratoire.sql`, `9 - VIEW dim DWH.sql`  
**SSIS Packages:** `Load_Dim.dtsx`, `Load_Fact.dtsx`

**Actions:**

#### Load Dimensions (`Load_Dim.dtsx`)
- **Dim_Shooting** - Incident-level attributes (victim demographics, manner of death)
- **Dim_City** - Geographic & city characteristics
- **Dim_Ethnicity** - Population demographics by state and race
- **Dim_Date** - Temporal dimension (date hierarchy for analysis)
- **Dim_Threat** - Threat level categorization
- Implement **Lookup transformations** to map IDs and prevent duplicates

#### Load Facts (`Load_Fact.dtsx`)
- **Fact_ShootingIncident** - Core transaction table
  - Foreign keys to all dimensions
  - Measures: incident count (grain: one row per shooting)
  - Fact table connects shooting details to geography, demographics, date, threat level

**Input:** Cleansed staging data  
**Output:** Dimensional model ready for analysis

---

### Phase 5: Analytics Views
**Script:** `11 - VIEW fact DWH.sql`

**Actions:**
- Create SQL views for common analytics queries
- Flatten dimension references for reporting
- Join fact to all relevant dimensions
- Ready for BI tools (Power BI, Tableau, Excel)

**Output:** User-friendly reporting views

## 📋 Execution Sequence

Follow these steps **in order**:

1. **Create Staging Database**
   ```sql
   CREATE DATABASE staging;
   CREATE DATABASE DWH_Labo;
   ```

2. **Step 1:** Execute `1 - CREATE TABLE staging.sql`
   - Creates raw staging tables

3. **Step 2:** Run SSIS Package `Extract_Load_Staging_Data.dtsx`
   - Loads CSV/XLSX files into staging tables

4. **Step 3:** Execute SQL scripts `3 - functions.sql`, `4 - CREATE SCHEMA.sql`, `5 - CITY.sql`
   - Prepare DWH schema and helper functions

5. **Step 4:** Run SSIS Package `Fuzzy.dtsx`
   - Fuzzy matching and data cleansing

6. **Step 5:** Execute SQL scripts `7 - CITY_view.sql`, `8 - CREATE TABLE DWH_Laboratoire.sql`, `9 - VIEW dim DWH.sql`
   - Create DWH tables and views

7. **Step 6:** Run SSIS Package `Load_Dim.dtsx`
   - Populate dimension tables

8. **Step 7:** Execute SQL script `11 - VIEW fact DWH.sql`
   - Create fact and reporting views

9. **Step 8:** Run SSIS Package `Load_Fact.dtsx`
   - Populate fact table

> **Note:** See `Execution_Process.txt` for quick reference

## 📊 Dimensional Data Model

### Dimension Tables

#### **Dim_Shooting**
Victim and incident attributes
- Victim name, demographics (age, gender, race)
- Manner of death, armed status
- Mental illness indicators, threat level

#### **Dim_City**
Geographic and city characteristics
- City name, state, coordinates (lat/lng)
- Population, population density
- County FIPS, timezone
- Linked to city population data

#### **Dim_Ethnicity**
Population statistics by state and race
- Ethnic/racial categories
- State-level population counts
- Total population for percentage calculations

#### **Dim_Date**
Temporal hierarchy for time-based analysis
- Date, year, month, quarter, day of week
- Fiscal period indicators

#### **Dim_Threat**
Threat level categorization
- Attack, other, undetermined
- Enables "what is the outcome by perceived threat?"

### Fact Table

#### **Fact_ShootingIncident**
Central transactional fact table
- **Foreign Keys:** Dim_Shooting, Dim_City, Dim_Ethnicity, Dim_Date, Dim_Threat
- **Measures:** Incident count (grain: one row per shooting)
- **Grain:** One row per fatal police shooting event
- Enables analysis by any dimension combination

## 🎯 Analytical Capabilities

### Geographic Analysis
- **Where do fatal shootings cluster?** - Identify high-incident cities/regions
- **Urban vs. rural patterns** - Compare shooting rates by city size (population)

### Demographic Analysis
- **Are shootings disproportionate by race?** - Compare incident rates to population demographics
- **Age distribution** - Which age groups are most affected?
- **Gender breakdown** - Patterns in male vs. female victims

### Temporal Analysis
- **Trends over time** - Increase/decrease in incidents by year, month
- **Seasonal patterns** - Are shootings more common in certain months?

### Circumstantial Analysis
- **Armed vs. unarmed incidents** - What % of victims were armed?
- **Threat levels** - Outcome by perceived threat (attack, other, undetermined)
- **Mental illness correlation** - Do incidents with mental illness flags differ?
- **Flight behavior** - Did fleeing impact outcome?
- **Body camera presence** - Correlations with incident resolution

### Composite Analysis
- **By state:** Incident counts, rates per population, demographic breakdowns
- **By city:** Local context (population, demographics, incident history)
- **By demographic group:** Intersection of race, age, gender, armed status

## 🛠️ Technical Stack

| Component | Technology |
|-----------|------------|
| **ETL Tool** | SSIS (SQL Server Integration Services) |
| **Database** | Microsoft SQL Server 2016+ |
| **Data Modeling** | Kimball Dimensional Modeling |
| **Scripting** | T-SQL (Transact-SQL) |
| **Data Quality** | Fuzzy Matching, Lookups, Deduplication |
| **Visualization** | Power BI, Tableau, Excel (via views) |

## ⚠️ Data Quality Considerations

### Challenges Addressed
1. **Inconsistent Location Names** - Fuzzy matching resolves city name variations
2. **Missing Data** - Nullable fields for incomplete records
3. **Geocoding Accuracy** - `is_geocoding_exact` flag allows filtering
4. **Duplicate Prevention** - Lookup transformations prevent record duplication
5. **Spelling Variations** - Fuzzy match handles typos (e.g., "St. Louis" vs "St Louis")

### Data Lineage
- Source data → Staging tables → Fuzzy cleansing → Cleansed staging → Dimensional warehouse
- All transformations documented in SSIS packages
- Manual reviews recommended for low-confidence fuzzy matches

### Validation Checks
- Foreign key relationships between dimensions and facts
- Temporal consistency (date ranges are logical)
- No negative measures (incident count must be ≥ 0)
- Completeness checks on critical fields (incident date, location, victim info)

## 🚀 Performance & Scalability

### Optimization Tips
- **Indexing:** Add primary key indexes on all dimension tables and foreign key columns in fact table
- **Incremental Loads:** Modify SSIS packages to detect new/changed records using timestamps
- **Aggregate Tables:** Create summary tables for common queries (e.g., incidents by state/year)
- **Partitioning:** Partition fact table by year for faster querying of historical data

### Current Limitations
- Manual fuzzy match review required for edge cases
- SSIS packages run sequentially (not parallelized)
- No automatic retry/recovery for failed loads

## 📚 File Reference

| File | Purpose | Type |
|------|---------|------|
| `Extract_Load_Staging_Data.dtsx` | Extract raw data | SSIS Package |
| `Fuzzy.dtsx` | Fuzzy matching & cleansing | SSIS Package |
| `Load_Dim.dtsx` | Populate dimensions | SSIS Package |
| `Load_Fact.dtsx` | Populate facts | SSIS Package |
| `1 - CREATE TABLE staging.sql` | Create staging schema | T-SQL |
| `3 - functions.sql` | Utility functions | T-SQL |
| `4 - CREATE SCHEMA.sql` | Create DWH schema | T-SQL |
| `5 - CITY.sql` | Load city dimension | T-SQL |
| `7 - CITY_view.sql` | City reference views | T-SQL |
| `8 - CREATE TABLE DWH_Laboratoire.sql` | Create DWH tables | T-SQL |
| `9 - VIEW dim DWH.sql` | Create dimension views | T-SQL |
| `11 - VIEW fact DWH.sql` | Create fact/reporting views | T-SQL |
| `DWH_Model.loo` | Data model diagram | Lucidchart |

## 🔧 Troubleshooting

### Common Issues

**Issue:** SSIS package fails on CSV import
- **Solution:** Check file path in connection manager; verify CSV format (delimiters, encoding)

**Issue:** Fuzzy match scores are low (< 0.6)
- **Solution:** Adjust similarity threshold in Fuzzy.dtsx; may indicate data quality issues in source

**Issue:** Foreign key constraint violations
- **Solution:** Verify lookups are executing correctly; check for NULL values in key fields

**Issue:** Fact table has fewer rows than expected
- **Solution:** Check lookup transformation settings (inner vs. left join); verify cleansed data completeness

## 📈 Future Enhancements

- [ ] Implement **slowly changing dimensions** (SCD Type II) to track demographic changes
- [ ] Add **time-series forecasting** views for trend analysis
- [ ] Create **dashboard templates** in Power BI
- [ ] Implement **incremental/delta loads** for efficiency
- [ ] Automate **data quality reports** and anomaly detection
- [ ] Add **external data** (police budget, training data, complaint data) for richer analysis
- [ ] Build **geospatial visualizations** (heat maps by location)
- [ ] Publish **web portal** for public analytics access

## 📄 Metadata & Documentation

**Data Model Diagram:** See `DWH_Model.loo` in LucidChart format  
**Execution Instructions:** See `Execution_Process.txt` for step-by-step guide  
**Data Descriptions:** See `about_datas.txt` for source data information

## ⚖️ Ethical Considerations

This project handles sensitive data on fatal police encounters. Appropriate considerations:

- **Privacy:** Individual victim names are retained but should be de-identified for public sharing
- **Bias Awareness:** Analysis results should acknowledge potential data collection biases
- **Responsible Use:** Findings should inform policy discussion, not drive discriminatory action
- **Data Governance:** Secure access controls; audit log all queries and exports

## 📞 Support & Questions

For issues or questions:
1. Review the **Execution_Process.txt** for step-by-step guidance
2. Check SSIS package configurations (connection managers, error paths)
3. Verify SQL syntax in scripts (copy/paste may introduce encoding issues)
4. Consult Microsoft SSIS and SQL Server documentation for platform-specific help

## 📄 License

Laboratory educational project. Use responsibly and in accordance with data privacy regulations.

---

**Last Updated:** September 2026  
**Project Status:** Active Development  
**Maintained By:** Data Engineering Lab
