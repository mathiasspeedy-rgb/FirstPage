from sudoku import Sudoku
from backtracking import Backtracking
from solver import Solver
from remover import Remover

import copy


def main():
    sudoku = Sudoku()
    backtracking = Backtracking(sudoku)

    success = backtracking.generate()

    if success:
        print("Grille générée avec succès :")
        sudoku.print_board()
    else:
        print("Aucune solution trouvée.")


def generate_puzzle(nb_case_a_retirer=10):
    sudoku = Sudoku()
    backtracking = Backtracking(sudoku)
    backtracking.generate()

    solution = copy.deepcopy(sudoku.board)

    remover = Remover(sudoku)
    sudoku.board = remover.remove(sudoku.board, nb_case_a_retirer)

    print()
    print("Grille trouée :")
    sudoku.print_board()

    solver = Solver(sudoku)
    print()
    print("Solution unique ?", solver.has_unique_solution())

    print("Solution :")
    for row in solution:
        print(row)



def solve_my_board(mon_board=None):
    if mon_board is None:
        # un board d'exemple par défaut -- remplace par ton propre board si besoin
        mon_board = [
            [None, 8, None, None, 9, 5, 4, 1, None],
            [None, None, 1, 8, None, None, None, 5, None],
            [None, 9, None, None, None, None, None, 6, 2],
            [None, 7, None, None, None, None, None, 8, None],
            [None, None, None, None, 7, None, None, None, None],
            [3, None, 9, 6, None, None, None, None, None],
            [1, None, 8, 4, None, None, 7, None, 5],
            [None, 6, 4, 7, None, None, None, None, 1],
            [None, None, None, None, 1, None, None, None, None],
        ]


    sudoku = Sudoku()
    sudoku.board = mon_board  # on remplace le board vide par défaut par le mien

    solver = Solver(sudoku)
    success = solver.count_solutions()
    print(success)
        

if __name__ == "__main__":
    generate_puzzle(46)