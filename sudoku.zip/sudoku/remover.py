from sudoku import Sudoku
from solver import Solver
import random


class Remover:
    def __init__(self, sudoku):
        self.sudoku = sudoku

    def remove(self, board, nb_case):
        case_removed = 0
        # compteur de sécurité pour éviter une boucle infinie si plus
        # aucune case ne peut être retirée sans casser l'unicité
        tentatives_max = 2000
        tentatives = 0

        while nb_case > case_removed and tentatives < tentatives_max:
            tentatives += 1

            random_line = random.randint(0, 8)
            random_column = random.randint(0, 8)

            if board[random_line][random_column] is None:
                continue

            # on sauvegarde juste la valeur de cette case précise,
            # pas besoin de copier tout le board pour ça
            valeur_avant = board[random_line][random_column]
            board[random_line][random_column] = None
            case_removed += 1

            # has_unique_solution doit recevoir LE BOARD à vérifier,
            # pas juste compter sur self.sudoku.board
            if not Solver(self.sudoku).has_unique_solution(board):
                board[random_line][random_column] = valeur_avant
                case_removed -= 1
        return board



        