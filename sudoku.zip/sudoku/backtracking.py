import random

from sudoku import Sudoku


class Backtracking:
    """Sait COMMENT chercher une solution. La pile de recherche n'est PAS
    réinitialisée à chaque valeur : elle contient les 81 niveaux (9
    valeurs x 9 carrés) en continu. Un recul peut donc traverser la
    frontière entre deux valeurs aussi naturellement qu'entre deux carrés
    d'une même valeur -- le recul se fait toujours un niveau à la fois,
    précisément au bon endroit."""

    SQUARES = [
        (0, 0), (1, 0), (2, 0),
        (0, 1), (1, 1), (2, 1),
        (0, 2), (1, 2), (2, 2),
    ]

    def __init__(self, sudoku=None):
        self.sudoku = sudoku if sudoku is not None else Sudoku()

    def _possibilities_for_square(self, square_index, value):
        """Coordonnées absolues encore disponibles pour ce carré, selon
        le boolean_board actuel (donc déjà net des valeurs précédentes
        ET des cases déjà prises plus haut dans la pile)."""
        offset = self.SQUARES[square_index]
        boolean_square = self.sudoku.get_square(self.sudoku.boolean_board, offset)
        relative_coords = self.sudoku.get_true_square(boolean_square)
        return [(r + offset[0] * 3, c + offset[1] * 3) for (r, c) in relative_coords]

    def _new_snapshot(self, value, square_index):
        if square_index == 0:
            # on entre dans une nouvelle valeur : le boolean_board doit
            # repartir des cases réellement vides du board (peu importe
            # quelle valeur les occupe), pas des contraintes de la valeur
            # précédente qui n'ont plus de sens ici.
            self.sudoku.boolean_board = self.sudoku.constraint_value(self.sudoku.board)

        possibilities = self._possibilities_for_square(square_index, value)
        random.shuffle(possibilities)
        return {
            "value": value,
            "square_index": square_index,
            "possibilities": possibilities,
            "wrong_placements": [],
            "current_candidate": None,
        }

    def _next_candidate(self, snapshot):
        for coor in snapshot["possibilities"]:
            if coor not in snapshot["wrong_placements"]:
                return coor
        return None

    def _next_level(self, value, square_index):
        """Donne (value, square_index) du prochain niveau de la pile :
        carré suivant si on n'est pas au carré 9, sinon valeur suivante
        en repartant du carré 1. None si on vient de finir la valeur 9
        au carré 9 (= grille complète)."""
        if square_index < len(self.SQUARES) - 1:
            return (value, square_index + 1)
        if value < 9:
            return (value + 1, 0)
        return None

    def generate(self):
        """Construit la grille complète en parcourant une pile UNIQUE de
        81 niveaux. Si un niveau n'a plus de candidat, on recule d'un
        niveau dans cette même pile -- qu'il s'agisse du carré précédent
        de la même valeur, ou du dernier carré de la valeur précédente.
        Retourne True si la grille est complète, False si la pile entière
        s'est vidée sans solution (cas qui ne devrait pas arriver pour un
        Sudoku standard, mais on le gère par sécurité)."""
        stack = [self._new_snapshot(1, 0)]

        while stack:
            snapshot = stack[-1]
            value = snapshot["value"]
            square_index = snapshot["square_index"]

            candidate = self._next_candidate(snapshot)

            if candidate is None:
                # ce niveau est épuisé : on recule d'un niveau dans LA MÊME pile,
                # que ce niveau précédent soit le carré d'avant ou la valeur d'avant
                stack.pop()
                if not stack:
                    return False  # plus rien où reculer : aucune solution

                previous = stack[-1]
                line, column = previous["current_candidate"]
                self.sudoku.undo(line, column)
                previous["wrong_placements"].append((line, column))
                previous["current_candidate"] = None
                continue

            line, column = candidate
            self.sudoku.place(line, column, value)
            snapshot["current_candidate"] = candidate

            next_level = self._next_level(value, square_index)
            if next_level is None:
                return True  # valeur 9, carré 9 : grille complète

            next_value, next_square = next_level
            stack.append(self._new_snapshot(next_value, next_square))

        return False