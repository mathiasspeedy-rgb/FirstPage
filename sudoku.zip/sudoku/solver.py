from sudoku import Sudoku


class Solver:

    def __init__(self, sudoku):
        self.sudoku = sudoku

    def _find_empty(self, board):
        """Renvoie la première case vide (si aucune return False) """
        for line in range(9):
            for column in range(9):
                if board[line][column] == None:
                    return (line, column)
        return False

    def candidate_cell_line(self, board, coord):
        """ renvoi les chiffres non presants d'une certaine ligne"""
        candidates = [1, 2, 3, 4, 5, 6, 7, 8, 9]
        for column in range(9):
            if board[coord[0]][column] != None:
                if board[coord[0]][column] in candidates:
                    candidates.remove(board[coord[0]][column])

        return candidates

    def candidate_cell_column(self, board, coord):
        """ renvoi les chiffres non presants d'une certaine colonne"""
        candidates = [1, 2, 3, 4, 5, 6, 7, 8, 9]
        for line in range(9):
            if board[line][coord[1]] != None:
                if board[line][coord[1]] in candidates:
                    candidates.remove(board[line][coord[1]])

        return candidates

    def find_square(self, board, coord):
        """ renvoie tout carré entier d'une certaine coordonée
        exemple coord : 2,4 renvoie tout le carré 0,1"""
        # coord[0] // 3 donne directement l'index de carré (0, 1 ou 2)
        # ex: ligne 2 -> 2//3 = 0 ; ligne 4 -> 4//3 = 1 ; ligne 7 -> 7//3 = 2
        square_index = (coord[0] // 3, coord[1] // 3)
        return self.sudoku.get_square(board, square_index)

    def candidate_square(self, board, coord):
        """ renvoie les chiffres non presants dans le carré 3x3 pour une case precise"""
        square = self.find_square(board, coord)
        candidates = [1, 2, 3, 4, 5, 6, 7, 8, 9]
        for line in range(3):
            for column in range(3):
                if square[line][column] != None:
                    if square[line][column] in candidates:
                        candidates.remove(square[line][column])

        return candidates

    def _candidate_for_cell(self, board, coord):
        """Renvoie les possibilités d'une case selon les règles du jeu"""
        candidate_line = self.candidate_cell_line(board, coord)
        candidate_column = self.candidate_cell_column(board, coord)
        candidate_square = self.candidate_square(board, coord)

        return list(set(candidate_line) & set(candidate_column) & set(candidate_square))

    def solve(self, board=None):
        """ teste chaque valeur possible(selon les règles d'unicité ligne,colonne,carré) dans le board 1par1
        se relance en cas d'echecs en passant à la valeur suivante 
        retourne le board remplis par la soluce"""
        if board is None:
            board = self.sudoku.board

        empty = self._find_empty(board)
        if empty == False:  # plus de case vide
            return True

        line, column = empty
        candidates = self._candidate_for_cell(board, empty)
        for value in candidates:
            board[line][column] = value
            if self.solve(board):
                return True
            board[line][column] = None
        return False
    
    def count_solutions(self,board=None,limit = 2):
        """lance une resolution du sudoku, quand réussi en relance une(différente) si il y arrive return True (donc plusieurs soltions else False)"""
        if board is None:
            board = self.sudoku.board
        empty = self._find_empty(board)

        if empty == False:  # plus de case vide
            return 1
        line, column = empty
        candidates = self._candidate_for_cell(board, empty)
        total = 0
        for value in candidates:
            board[line][column] = value
            total += self.count_solutions(board,limit - total)
            board[line][column] = None
            if total >= limit:
                break
        
        return total
    
    def has_unique_solution(self,board = None):
        """ True si une seule solution"""
        return self.count_solutions(board,limit=2) == 1
    
