import random


class Sudoku:
    """Connaît uniquement les règles du Sudoku : représentation du board,
    des contraintes (boolean_board), et comment poser/annuler un coup.
    Ne sait PAS comment chercher une solution -- ça sera le rôle de la
    classe Backtracking, séparée."""

    def __init__(self):
        self.board = self.create_board()
        self.boolean_board = self.create_boolean_board()
        # pile d'historique : chaque élément est une sauvegarde du
        # boolean_board, prise juste avant un place(). undo() la restaure.
        self._history = []

    """cree un board vide"""
    def create_board(self):
        board = []
        for line in range(9):
            row = []
            for column in range(9):
                row.append(None)
            board.append(row)
        return board

    """cree un boolean_board (fullTrue)"""
    def create_boolean_board(self):
        boolean_board = []
        for line in range(9):
            row = []
            for column in range(9):
                row.append(True)
            boolean_board.append(row)
        return boolean_board

    """rend les coordonées qui sont True"""
    def get_true_square(self, boolean_square):
        true_coords = []
        for line in range(len(boolean_square)):
            for column in range(len(boolean_square[0])):
                if boolean_square[line][column]:
                    true_coords.append((line, column))
        return true_coords

    """retourne le carré demandé du tableau (ex: square = (0,0))"""
    def get_square(self, tab, square):
        result_square = [[None] * 3 for _ in range(3)]
        for line in range(3):
            for column in range(3):
                result_square[line][column] = tab[line + 3 * square[0]][column + 3 * square[1]]
        return result_square

    """met false a chaque ligne d'une colonne donnée"""
    def constraint_column(self, boolean_board, column):
        for line in range(9):
            boolean_board[line][column] = False
        return boolean_board

    """met false a chaque colonne d'une ligne donnée"""
    def constraint_line(self, boolean_board, line):
        for column in range(9):
            boolean_board[line][column] = False
        return boolean_board

    """met true a chaque valeur vide et false aux autres"""
    def constraint_value(self, board):
        boolean_board = []
        for line in range(9):
            row = []
            for column in range(9):
                row.append(board[line][column] is None)
            boolean_board.append(row)
        return boolean_board

    def is_cell_free(self, line, column):
        return self.boolean_board[line][column]

    def place(self, line, column, value):
        """Pose value en (line, column), met à jour boolean_board,
        et sauvegarde l'état précédent pour permettre un undo() exact."""
        self._history.append([row[:] for row in self.boolean_board])

        self.board[line][column] = value
        self.boolean_board = self.constraint_line(self.boolean_board, line)
        self.boolean_board = self.constraint_column(self.boolean_board, column)

    def undo(self, line, column):
        """Annule le dernier place() : remet None et restaure exactement
        le boolean_board sauvegardé juste avant ce place()."""
        if not self._history:
            raise RuntimeError("undo() appelé sans place() correspondant")

        self.board[line][column] = None
        self.boolean_board = self._history.pop()

    def print_board(self):
        for row in self.board:
            print(row)